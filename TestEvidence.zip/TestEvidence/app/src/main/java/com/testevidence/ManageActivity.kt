package com.testevidence

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Collections
import java.util.concurrent.Executors

class ManageActivity : Activity() {

    private lateinit var inst: String
    private val pool = Executors.newFixedThreadPool(2)
    private var sv: ScrollView? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        inst = intent.getStringExtra("inst") ?: "C1"
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onDestroy() {
        pool.shutdownNow()
        super.onDestroy()
    }

    private fun render() {
        val files = Store.files(this, inst)
        val y = sv?.scrollY ?: 0
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(24))
        }
        root.addView(TextView(this).apply {
            text = inst + "  |  " + files.size + " screenshot(s)"
            textSize = 20f
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        root.addView(Button(this).apply {
            text = "Back"
            isAllCaps = false
            setOnClickListener { finish() }
        })
        if (files.isEmpty()) {
            root.addView(TextView(this).apply { text = "No screenshots yet."; setPadding(0, dp(16), 0, 0) })
        }
        files.forEachIndexed { idx, _ -> root.addView(row(files, idx)) }
        val s = ScrollView(this).apply { addView(root) }
        sv = s
        setContentView(s)
        s.post { s.scrollTo(0, y) }
    }

    private fun small(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(10), 0, dp(10), 0)
        setOnClickListener { onClick() }
    }

    private fun row(files: List<File>, idx: Int): LinearLayout {
        val f = files[idx]
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        val iv = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(72), dp(72))
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFFEEEEEE.toInt())
            setOnClickListener { open(f) }
        }
        pool.execute {
            val bm = thumb(f)
            runOnUiThread { iv.setImageBitmap(bm) }
        }
        row.addView(iv)
        row.addView(TextView(this).apply {
            text = f.name
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(dp(10), 0, 0, 0)
        })
        if (idx > 0) row.addView(small("↑") { swap(files, idx, idx - 1) })
        if (idx < files.size - 1) row.addView(small("↓") { swap(files, idx, idx + 1) })
        row.addView(small("Delete") {
            AlertDialog.Builder(this)
                .setTitle("Delete " + f.name + "?")
                .setMessage("Remaining screenshots will be renumbered.")
                .setPositiveButton("Delete") { _, _ -> Store.delete(this, inst, f); render() }
                .setNegativeButton("Cancel", null)
                .show()
        })
        return row
    }

    private fun swap(files: List<File>, a: Int, b: Int) {
        val l = files.toMutableList()
        Collections.swap(l, a, b)
        Store.renumber(this, inst, l)
        render()
    }

    private fun open(f: File) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(Store.uriFor(this, f), "image/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            Toast.makeText(this, "No app found to open images", Toast.LENGTH_SHORT).show()
        }
    }

    private fun thumb(f: File): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= 200 && o.outHeight / (s * 2) >= 200) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }
}
