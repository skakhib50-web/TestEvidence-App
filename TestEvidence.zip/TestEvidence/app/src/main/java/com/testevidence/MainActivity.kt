package com.testevidence

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.net.Uri
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { render() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun w() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        ContextCompat.registerReceiver(
            this, receiver, IntentFilter(ScreenshotService.ACTION_UPDATED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        render()
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    private fun render() {
        val running = Store.running(this)
        val active = Store.active(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(24))
        }
        root.addView(TextView(this).apply {
            text = "Test Evidence Collector"
            textSize = 22f
            setTypeface(null, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = if (running) "● Capturing. New screenshots go to $active" else "○ Not capturing"
            setPadding(0, dp(8), 0, dp(8))
        })
        root.addView(btn(if (running) "Stop capturing" else "Start capturing") {
            if (running) stopCapture() else startCapture()
        })
        Store.INSTANCES.forEach { root.addView(card(it, it == active)) }
        root.addView(btn("Zip & Share ALL instances") { zipAndShare(Store.INSTANCES) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(16) })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun card(inst: String, isActive: Boolean): View {
        val n = Store.files(this, inst).size
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(if (isActive) 0xFFE3F2FD.toInt() else 0xFFF5F5F5.toInt())
                setStroke(dp(2), if (isActive) 0xFF1565C0.toInt() else 0xFFDDDDDD.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) }
        }
        box.addView(TextView(this).apply {
            text = inst + "  |  " + n + " screenshot(s)" + if (isActive) "  (ACTIVE)" else ""
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
        })
        val r1 = LinearLayout(this)
        r1.addView(btn("Set active") { setActive(inst) }, w())
        r1.addView(btn("Manage") {
            startActivity(Intent(this, ManageActivity::class.java).putExtra("inst", inst))
        }, w())
        val r2 = LinearLayout(this)
        r2.addView(btn("Zip & Share") { zipAndShare(listOf(inst)) }, w())
        r2.addView(btn("Clear") {
            AlertDialog.Builder(this)
                .setTitle("Clear $inst?")
                .setMessage("Delete all $n screenshot(s) in $inst from this app?")
                .setPositiveButton("Delete") { _, _ -> Store.clear(this, inst); render() }
                .setNegativeButton("Cancel", null)
                .show()
        }, w())
        box.addView(r1)
        box.addView(r2)
        return box
    }

    private fun setActive(inst: String) {
        Store.setActive(this, inst)
        if (Store.running(this)) {
            startService(Intent(this, ScreenshotService::class.java)
                .setAction(ScreenshotService.ACTION_SWITCH).putExtra("inst", inst))
        }
        render()
    }

    private fun zipAndShare(list: List<String>) {
        toast("Preparing zip...")
        Thread {
            val zips = list.mapNotNull { Store.zip(this, it) }
            runOnUiThread {
                if (zips.isEmpty()) toast("No screenshots to zip") else Store.shareZips(this, zips)
            }
        }.start()
    }

    private fun mediaPerm() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun startCapture() {
        val need = ArrayList<String>()
        if (checkSelfPermission(mediaPerm()) != PackageManager.PERMISSION_GRANTED) need.add(mediaPerm())
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT < 30 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), 1); return }
        proceedAfterPerms()
    }

    private fun proceedAfterPerms() {
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            toast("Turn ON \"Allow access to manage all files\" for this app, then come back and tap Start again.")
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + packageName))
            )
            return
        }
        launchService()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(mediaPerm()) == PackageManager.PERMISSION_GRANTED) proceedAfterPerms()
        else toast("Photos access (Allow all) is needed to detect screenshots")
    }

    private fun launchService() {
        ContextCompat.startForegroundService(this, Intent(this, ScreenshotService::class.java))
    }

    private fun stopCapture() {
        startService(Intent(this, ScreenshotService::class.java).setAction(ScreenshotService.ACTION_STOP))
        Store.setRunning(this, false)
        render()
    }
}
