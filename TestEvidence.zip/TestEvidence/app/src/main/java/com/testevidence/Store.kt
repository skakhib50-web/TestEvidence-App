package com.testevidence

import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object Store {
    val INSTANCES = listOf("C1", "C2", "C3")

    private fun p(c: Context) = c.getSharedPreferences("te", Context.MODE_PRIVATE)

    fun active(c: Context): String = p(c).getString("active", "C1") ?: "C1"
    fun setActive(c: Context, i: String) = p(c).edit().putString("active", i).apply()
    fun lastId(c: Context): Long = p(c).getLong("lastId", 0L)
    fun setLastId(c: Context, v: Long) = p(c).edit().putLong("lastId", v).apply()
    fun running(c: Context): Boolean = p(c).getBoolean("running", false)
    fun setRunning(c: Context, v: Boolean) = p(c).edit().putBoolean("running", v).apply()

    fun root(c: Context): File {
        val base = c.getExternalFilesDir(null) ?: c.filesDir
        return File(base, "TestEvidence").also { it.mkdirs() }
    }

    fun dir(c: Context, inst: String): File = File(root(c), inst).also { it.mkdirs() }

    fun files(c: Context, inst: String): List<File> =
        dir(c, inst).listFiles()?.filter { it.isFile && !it.name.startsWith(".") }?.sortedBy { it.name }
            ?: emptyList()

    private val numRe = Regex("_(\\d+)\\.[A-Za-z0-9]+$")

    fun nextFile(c: Context, inst: String, ext: String): File {
        val max = files(c, inst).maxOfOrNull { numRe.find(it.name)?.groupValues?.get(1)?.toIntOrNull() ?: 0 } ?: 0
        return File(dir(c, inst), String.format(Locale.US, "%s_%03d.%s", inst, max + 1, ext))
    }

    /** Renames the given files, in the given order, to INST_001, INST_002, ... */
    fun renumber(c: Context, inst: String, ordered: List<File>) {
        val d = dir(c, inst)
        val temps = ordered.mapIndexed { i, f ->
            val t = File(d, ".tmp_$i")
            f.renameTo(t)
            Pair(t, f.extension)
        }
        temps.forEachIndexed { i, pair ->
            pair.first.renameTo(File(d, String.format(Locale.US, "%s_%03d.%s", inst, i + 1, pair.second)))
        }
    }

    fun delete(c: Context, inst: String, f: File) {
        f.delete()
        renumber(c, inst, files(c, inst))
    }

    fun clear(c: Context, inst: String) {
        files(c, inst).forEach { it.delete() }
    }

    fun zip(c: Context, inst: String): File? {
        val list = files(c, inst)
        if (list.isEmpty()) return null
        val zd = File(root(c), "_zips").also { it.mkdirs() }
        zd.listFiles()?.filter { it.name.startsWith(inst + "_") }?.forEach { it.delete() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        val out = File(zd, inst + "_" + stamp + ".zip")
        ZipOutputStream(out.outputStream().buffered()).use { z ->
            list.forEach { f ->
                z.putNextEntry(ZipEntry(f.name))
                f.inputStream().use { it.copyTo(z) }
                z.closeEntry()
            }
        }
        return out
    }

    fun uriFor(c: Context, f: File): Uri =
        FileProvider.getUriForFile(c, c.packageName + ".fileprovider", f)

    fun shareZips(act: Activity, zips: List<File>) {
        val uris = ArrayList(zips.map { uriFor(act, it) })
        val i = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        i.type = "application/zip"
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val clip = ClipData.newRawUri("zip", uris[0])
        for (k in 1 until uris.size) clip.addItem(ClipData.Item(uris[k]))
        i.clipData = clip
        act.startActivity(Intent.createChooser(i, "Share zip"))
    }
}
