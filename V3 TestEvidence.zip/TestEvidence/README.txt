Test Evidence Collector
Build option A: open this folder in Android Studio -> Build > Build APK(s).
Build option B: upload this folder to a GitHub repo -> Actions tab -> "Build APK" -> download artifact.
