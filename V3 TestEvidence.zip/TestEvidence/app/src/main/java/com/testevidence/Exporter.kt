package com.testevidence

import android.app.Activity
import android.app.AlertDialog
import android.widget.Toast
import java.io.File

object Exporter {
    fun ask(act: Activity, insts: List<String>) {
        val opts = arrayOf("Zip file (.zip)", "Word document (.docx, 2 images per row)", "Both zip and Word")
        AlertDialog.Builder(act)
            .setTitle("Export " + insts.joinToString(", "))
            .setItems(opts) { _, which -> run(act, insts, which) }
            .show()
    }

    private fun run(act: Activity, insts: List<String>, which: Int) {
        Toast.makeText(act, "Preparing file...", Toast.LENGTH_SHORT).show()
        Thread {
            val out = ArrayList<File>()
            try {
                insts.forEach { inst ->
                    if (which == 0 || which == 2) Store.zip(act, inst)?.let { out.add(it) }
                    if (which >= 1) Docx.build(act, inst)?.let { out.add(it) }
                }
            } catch (e: Exception) {
                act.runOnUiThread { Toast.makeText(act, "Export failed: " + e.message, Toast.LENGTH_LONG).show() }
                return@Thread
            }
            act.runOnUiThread {
                if (out.isEmpty()) Toast.makeText(act, "No screenshots to export", Toast.LENGTH_SHORT).show()
                else Store.shareFiles(act, out)
            }
        }.start()
    }
}
