package com.testevidence

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** Translucent concentric-circle button (like an assistive touch ball). */
class BubbleView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) / 2f
        p.style = Paint.Style.FILL
        p.color = 0xCC111827.toInt()
        c.drawCircle(cx, cy, r, p)
        p.color = 0x66FFFFFF
        c.drawCircle(cx, cy, r * 0.80f, p)
        p.color = 0xB3374151.toInt()
        c.drawCircle(cx, cy, r * 0.64f, p)
        p.color = 0xEEFFFFFF.toInt()
        c.drawCircle(cx, cy, r * 0.46f, p)
    }
}
