package com.testevidence

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.annotation.RequiresApi
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Hosts the floating circle (only while capturing is ON) and the soft name popup.
 * Uses the accessibility "take screenshot" call, so no gallery copy/delete is needed.
 * Idle cost is near zero: it listens to no accessibility events.
 */
class CaptureAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: CaptureAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var wm: WindowManager? = null
    private var bubble: BubbleView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var popup: View? = null
    private var lastTap = 0L
    private val dismissPopup = Runnable { removePopup() }

    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var dragging = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        refreshOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        instance = null
        handler.removeCallbacksAndMessages(null)
        removeBubble()
        removePopup()
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    // ---------------- floating circle ----------------

    fun refreshOverlay() {
        handler.post {
            if (wm != null && Store.running(this) && Store.bubbleEnabled(this)) showBubble() else removeBubble()
        }
    }

    private fun showBubble() {
        val manager = wm ?: return
        val sizePx = dp(Store.bubbleDp(this))
        val dm = resources.displayMetrics
        val existing = bubble
        val oldLp = bubbleLp
        if (existing != null && oldLp != null) {
            oldLp.width = sizePx
            oldLp.height = sizePx
            oldLp.x = oldLp.x.coerceIn(0, (dm.widthPixels - sizePx).coerceAtLeast(0))
            oldLp.y = oldLp.y.coerceIn(0, (dm.heightPixels - sizePx).coerceAtLeast(0))
            existing.alpha = Store.bubbleOpacity(this) / 100f
            try { manager.updateViewLayout(existing, oldLp) } catch (e: Exception) {}
            return
        }
        val v = BubbleView(this)
        v.alpha = Store.bubbleOpacity(this) / 100f
        val lp = WindowManager.LayoutParams(
            sizePx, sizePx,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = Store.bubbleX(this, dm.widthPixels - sizePx - dp(12))
            .coerceIn(0, (dm.widthPixels - sizePx).coerceAtLeast(0))
        lp.y = Store.bubbleY(this, dm.heightPixels / 3)
            .coerceIn(0, (dm.heightPixels - sizePx).coerceAtLeast(0))
        v.setOnTouchListener { view, ev -> onBubbleTouch(view, ev) }
        try {
            manager.addView(v, lp)
            bubble = v
            bubbleLp = lp
        } catch (e: Exception) {
            toast("Could not show the floating button")
        }
    }

    private fun removeBubble() {
        val v = bubble
        if (v != null) {
            try { wm?.removeView(v) } catch (e: Exception) {}
        }
        bubble = null
        bubbleLp = null
    }

    private fun onBubbleTouch(v: View, e: MotionEvent): Boolean {
        val lp = bubbleLp ?: return false
        val manager = wm ?: return false
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        val dm = resources.displayMetrics
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                startX = lp.x
                startY = lp.y
                dragging = false
                v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(90).start()
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                if (dragging) {
                    lp.x = (startX + dx).toInt().coerceIn(0, (dm.widthPixels - lp.width).coerceAtLeast(0))
                    lp.y = (startY + dy).toInt().coerceIn(0, (dm.heightPixels - lp.height).coerceAtLeast(0))
                    try { manager.updateViewLayout(v, lp) } catch (ex: Exception) {}
                }
            }
            MotionEvent.ACTION_UP -> {
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                if (dragging) Store.setBubblePos(this, lp.x, lp.y) else capture()
            }
            MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }
        return true
    }

    // ---------------- capture ----------------

    private fun capture() {
        if (Build.VERSION.SDK_INT < 30) {
            toast("The floating button needs Android 11 or newer")
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (now - lastTap < 900) return
        lastTap = now
        removePopup()
        bubble?.visibility = View.INVISIBLE
        handler.postDelayed({ takeNow() }, 160)
    }

    @RequiresApi(30)
    private fun takeNow() {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                val hb = result.hardwareBuffer
                val cs = result.colorSpace
                worker.execute {
                    var saved: File? = null
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(hb, cs)
                        if (hw != null) {
                            val bmp = hw.copy(Bitmap.Config.ARGB_8888, false)
                            hw.recycle()
                            if (bmp != null) {
                                saved = save(bmp)
                                bmp.recycle()
                            }
                        }
                    } catch (e: Throwable) {
                        // fall through; saved stays null
                    } finally {
                        try { hb.close() } catch (e: Throwable) {}
                    }
                    val done = saved
                    handler.post {
                        bubble?.visibility = View.VISIBLE
                        if (done != null) afterSaved(done) else toast("Could not capture this screen")
                    }
                }
            }

            override fun onFailure(errorCode: Int) {
                handler.post {
                    bubble?.visibility = View.VISIBLE
                    toast("Capture blocked for this screen (code $errorCode)")
                }
            }
        })
    }

    private fun save(bmp: Bitmap): File {
        val inst = Store.active(this)
        val sfx = Store.suffixFor(Store.currentModule(this), "")
        val dest = Store.nextFile(this, inst, "png", sfx)
        dest.outputStream().buffered().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return dest
    }

    private fun afterSaved(f: File) {
        ScreenshotService.instance?.refreshNotification()
        sendBroadcast(Intent(ScreenshotService.ACTION_UPDATED).setPackage(packageName))
        showPopup(f)
    }

    // ---------------- soft name popup ----------------

    private fun removePopup() {
        handler.removeCallbacks(dismissPopup)
        val v = popup
        if (v != null) {
            try { wm?.removeView(v) } catch (e: Exception) {}
        }
        popup = null
    }

    private fun showPopup(f: File) {
        val manager = wm ?: return
        removePopup()
        val dm = resources.displayMetrics
        val inst = f.parentFile?.name ?: ""

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(14), dp(14), dp(14), dp(14))
        card.background = Ui.rounded(this, 0xC8111827.toInt(), 26, 0x33FFFFFF, 1)

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val iv = ImageView(this)
        iv.layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.background = Ui.rounded(this, 0x22FFFFFF, 12)
        iv.clipToOutline = true
        Ui.loadInto(iv, f, 160)
        top.addView(iv)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        col.setPadding(dp(12), 0, 0, 0)
        col.addView(Ui.text(this, "Screenshot saved", 15f, Ui.WHITE, true))
        col.addView(Ui.text(this, "Saved to $inst as " + Store.caption(f), 12f, 0xB3FFFFFF.toInt()))
        top.addView(col)
        card.addView(top)

        val et = EditText(this)
        et.hint = "Name this screenshot (optional)"
        et.setHintTextColor(0x80FFFFFF.toInt())
        et.setTextColor(Ui.WHITE)
        et.textSize = 15f
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        et.setSingleLine(true)
        et.imeOptions = EditorInfo.IME_ACTION_DONE
        et.setPadding(dp(14), dp(12), dp(14), dp(12))
        et.background = Ui.rounded(this, 0x26FFFFFF, 14)
        val etLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        etLp.topMargin = dp(12)
        card.addView(et, etLp)

        val doSave = {
            val n = Store.clean(et.text.toString())
            if (n.isNotEmpty()) {
                val nf = Store.rename(this, inst, f, n, Store.info(f).module)
                toast("Saved as " + (nf?.nameWithoutExtension ?: f.nameWithoutExtension))
                sendBroadcast(Intent(ScreenshotService.ACTION_UPDATED).setPackage(packageName))
                ScreenshotService.instance?.refreshNotification()
            }
            removePopup()
        }

        val row = LinearLayout(this)
        row.setPadding(0, dp(12), 0, 0)
        row.addView(Ui.button(this, "Skip", 0x26FFFFFF, Ui.WHITE) { removePopup() }, Ui.weight(this))
        row.addView(Ui.button(this, "Save name", 0xFF2563EB.toInt(), Ui.WHITE) { doSave() }, Ui.weight(this))
        card.addView(row)

        val w = minOf(dm.widthPixels - dp(32), dp(420))
        val lp = WindowManager.LayoutParams(
            w, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        lp.y = dp(28)
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE

        // keep the app underneath usable until the user taps the name field
        et.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_DOWN) {
                if (lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE != 0) {
                    lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
                    try { manager.updateViewLayout(card, lp) } catch (e: Exception) {}
                }
                et.requestFocus()
                handler.postDelayed({
                    val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
                }, 120)
                handler.removeCallbacks(dismissPopup)
                handler.postDelayed(dismissPopup, 25_000)
            }
            false
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(dismissPopup)
                handler.postDelayed(dismissPopup, 25_000)
            }
        })
        et.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { doSave(); true } else false
        }

        try {
            manager.addView(card, lp)
            popup = card
            card.alpha = 0f
            card.translationY = dp(24).toFloat()
            card.animate().alpha(1f).translationY(0f).setDuration(240).start()
            handler.postDelayed(dismissPopup, 7_000)
        } catch (e: Exception) {
            toast("Saved as " + Store.caption(f))
        }
    }
}
