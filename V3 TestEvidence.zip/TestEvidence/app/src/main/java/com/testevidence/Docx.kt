package com.testevidence

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Writes a .docx by hand (no libraries): 2 pictures per table row, grouped by module. */
object Docx {
    private const val EMU_IN = 914400.0
    private const val MAX_SIDE = 1600

    private class Jpg(val bytes: ByteArray, val w: Int, val h: Int)
    private class Pic(val id: Int, val cx: Long, val cy: Long, val caption: String)

    private fun esc(s: String) =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun put(z: ZipOutputStream, name: String, text: String) {
        z.putNextEntry(ZipEntry(name))
        z.write(text.toByteArray(Charsets.UTF_8))
        z.closeEntry()
    }

    private fun jpeg(f: File): Jpg? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / (s * 2) >= MAX_SIDE) s *= 2
        var bm = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
        val big = maxOf(bm.width, bm.height)
        if (big > MAX_SIDE) {
            val k = MAX_SIDE.toFloat() / big
            val sc = Bitmap.createScaledBitmap(
                bm, (bm.width * k).toInt().coerceAtLeast(1), (bm.height * k).toInt().coerceAtLeast(1), true
            )
            if (sc !== bm) { bm.recycle(); bm = sc }
        }
        val bos = ByteArrayOutputStream()
        bm.compress(Bitmap.CompressFormat.JPEG, 85, bos)
        val r = Jpg(bos.toByteArray(), bm.width, bm.height)
        bm.recycle()
        return r
    }

    private fun para(text: String, sizeHalfPt: Int, color: String, bold: Boolean, before: Int, after: Int, center: Boolean): String {
        val sb = StringBuilder()
        sb.append("<w:p><w:pPr><w:keepNext/><w:spacing w:before=\"").append(before).append("\" w:after=\"").append(after).append("\"/>")
        if (center) sb.append("<w:jc w:val=\"center\"/>")
        sb.append("</w:pPr><w:r><w:rPr>")
        if (bold) sb.append("<w:b/>")
        sb.append("<w:color w:val=\"").append(color).append("\"/><w:sz w:val=\"").append(sizeHalfPt).append("\"/></w:rPr>")
        sb.append("<w:t xml:space=\"preserve\">").append(esc(text)).append("</w:t></w:r></w:p>")
        return sb.toString()
    }

    private fun picPara(p: Pic): String =
        "<w:p><w:pPr><w:keepNext/><w:jc w:val=\"center\"/></w:pPr><w:r><w:drawing>" +
            "<wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\">" +
            "<wp:extent cx=\"${p.cx}\" cy=\"${p.cy}\"/>" +
            "<wp:docPr id=\"${p.id}\" name=\"Picture ${p.id}\"/>" +
            "<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect=\"1\"/></wp:cNvGraphicFramePr>" +
            "<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
            "<pic:pic><pic:nvPicPr><pic:cNvPr id=\"${p.id}\" name=\"image${p.id}.jpg\"/><pic:cNvPicPr/></pic:nvPicPr>" +
            "<pic:blipFill><a:blip r:embed=\"rId${p.id}\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
            "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"${p.cx}\" cy=\"${p.cy}\"/></a:xfrm>" +
            "<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>" +
            "</a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>"

    private fun cell(p: Pic?): String {
        val sb = StringBuilder("<w:tc><w:tcPr><w:tcW w:w=\"4945\" w:type=\"dxa\"/></w:tcPr>")
        if (p == null) {
            sb.append("<w:p/>")
        } else {
            sb.append(picPara(p))
            sb.append(
                "<w:p><w:pPr><w:jc w:val=\"center\"/></w:pPr><w:r><w:rPr><w:color w:val=\"555555\"/><w:sz w:val=\"18\"/></w:rPr>" +
                    "<w:t xml:space=\"preserve\">" + esc(p.caption) + "</w:t></w:r></w:p>"
            )
        }
        sb.append("</w:tc>")
        return sb.toString()
    }

    private fun table(pics: List<Pic>): String {
        val b = "w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"D7DDE8\""
        val sb = StringBuilder()
        sb.append("<w:tbl><w:tblPr><w:tblW w:w=\"9890\" w:type=\"dxa\"/><w:tblBorders>")
        sb.append("<w:top $b/><w:left $b/><w:bottom $b/><w:right $b/><w:insideH $b/><w:insideV $b/>")
        sb.append("</w:tblBorders><w:tblLayout w:type=\"fixed\"/>")
        sb.append("<w:tblCellMar><w:top w:w=\"80\" w:type=\"dxa\"/><w:left w:w=\"100\" w:type=\"dxa\"/>")
        sb.append("<w:bottom w:w=\"80\" w:type=\"dxa\"/><w:right w:w=\"100\" w:type=\"dxa\"/></w:tblCellMar></w:tblPr>")
        sb.append("<w:tblGrid><w:gridCol w:w=\"4945\"/><w:gridCol w:w=\"4945\"/></w:tblGrid>")
        var i = 0
        while (i < pics.size) {
            sb.append("<w:tr><w:trPr><w:cantSplit/></w:trPr>")
            sb.append(cell(pics[i]))
            sb.append(cell(if (i + 1 < pics.size) pics[i + 1] else null))
            sb.append("</w:tr>")
            i += 2
        }
        sb.append("</w:tbl><w:p/>")
        return sb.toString()
    }

    fun build(c: Context, inst: String): File? {
        val gs = Store.groups(c, inst)
        if (gs.isEmpty()) return null
        val zd = Store.exportDir(c)
        zd.listFiles()?.filter { it.name.startsWith(inst + "_") && it.extension == "docx" }?.forEach { it.delete() }
        val out = File(zd, inst + "_" + Store.stamp() + ".docx")

        val maxW = 3.2 * EMU_IN
        val maxH = 4.6 * EMU_IN
        val body = StringBuilder()
        val rels = StringBuilder()
        val now = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US).format(Date())
        body.append(para("$inst  -  Test Evidence", 40, "0B1F44", true, 0, 60, false))
        body.append(para("Generated: $now", 20, "6B7280", false, 0, 200, false))

        ZipOutputStream(out.outputStream().buffered()).use { z ->
            put(z, "[Content_Types].xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                    "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                    "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                    "<Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>" +
                    "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
                    "</Types>")
            put(z, "_rels/.rels",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
                    "</Relationships>")

            var n = 0
            gs.forEach { g ->
                if (gs.size > 1 || g.first.isNotBlank()) {
                    body.append(para(if (g.first.isBlank()) "General" else "Module: " + g.first, 30, "1565C0", true, 240, 120, false))
                }
                val pics = ArrayList<Pic>()
                g.second.forEach { f ->
                    val j = jpeg(f)
                    if (j != null) {
                        n++
                        z.putNextEntry(ZipEntry("word/media/image$n.jpg"))
                        z.write(j.bytes)
                        z.closeEntry()
                        rels.append("<Relationship Id=\"rId$n\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/image$n.jpg\"/>")
                        val k = minOf(maxW / j.w, maxH / j.h)
                        pics.add(Pic(n, (j.w * k).toLong(), (j.h * k).toLong(), Store.caption(f)))
                    }
                }
                if (pics.isNotEmpty()) body.append(table(pics))
            }

            put(z, "word/document.xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
                    "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
                    "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" " +
                    "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
                    "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><w:body>" +
                    body.toString() +
                    "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>" +
                    "<w:pgMar w:top=\"1008\" w:right=\"1008\" w:bottom=\"1008\" w:left=\"1008\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/>" +
                    "</w:sectPr></w:body></w:document>")
            put(z, "word/_rels/document.xml.rels",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    rels.toString() + "</Relationships>")
        }
        return out
    }
}
