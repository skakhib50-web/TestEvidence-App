package com.testevidence

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

class TrashActivity : Activity() {

    private fun dp(v: Int) = Ui.dp(this, v)
    private val head = 0xFF374151.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = head
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val items = Store.trash(this)

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setBackgroundColor(Ui.BG)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(22), dp(34), dp(22), dp(22))
        val hb = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF111827.toInt(), head))
        val r = dp(32).toFloat()
        hb.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        header.background = hb
        header.elevation = dp(6).toFloat()
        val back = Ui.text(this, "‹  Back", 15f, Color.WHITE, true)
        back.setPadding(0, 0, 0, dp(10))
        back.setOnClickListener { finish() }
        header.addView(back)
        header.addView(Ui.text(this, "Recently deleted", 28f, Color.WHITE, true))
        val sub = Ui.text(
            this, items.size.toString() + " item(s). Removed for good after " + Store.TRASH_DAYS + " days.",
            13f, 0xCCFFFFFF.toInt()
        )
        sub.setPadding(0, dp(2), 0, dp(16))
        header.addView(sub)
        header.addView(Ui.button(this, "Delete ALL permanently", 0x33FFFFFF, Color.WHITE) {
            if (items.isEmpty()) return@button
            AlertDialog.Builder(this)
                .setTitle("Delete all permanently?")
                .setMessage("This cannot be undone.")
                .setPositiveButton("Delete") { _, _ -> Store.emptyTrash(this); render() }
                .setNegativeButton("Cancel", null)
                .show()
        })
        page.addView(header)

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(16), dp(6), dp(16), dp(26))
        if (items.isEmpty()) {
            val e = Ui.text(this, "Nothing here.\nDeleted screenshots appear in this list.", 15f, Ui.GREY)
            e.setPadding(dp(4), dp(30), dp(4), 0)
            body.addView(e)
        }
        items.forEach { body.addView(row(it)) }
        page.addView(body)

        val s = ScrollView(this)
        s.setBackgroundColor(Ui.BG)
        s.addView(page)
        setContentView(s)
    }

    private fun row(t: Store.TrashItem): View {
        val color = Ui.colorFor(t.inst)
        val info = Store.trashInfo(t)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(14), dp(14), dp(14), dp(14))
        box.background = Ui.rounded(this, Color.WHITE, 20)
        box.elevation = dp(3).toFloat()
        box.layoutParams = Ui.lp().apply { topMargin = dp(12) }

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val iv = ImageView(this)
        iv.layoutParams = LinearLayout.LayoutParams(dp(70), dp(70))
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.background = Ui.rounded(this, Ui.tint(color), 14)
        iv.clipToOutline = true
        iv.setOnClickListener {
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW)
                        .setDataAndType(Store.uriFor(this, t.file), "image/*")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                )
            } catch (e: Exception) {
                Toast.makeText(this, "No app found to open images", Toast.LENGTH_SHORT).show()
            }
        }
        Ui.loadInto(iv, t.file)
        top.addView(iv)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        col.setPadding(dp(14), 0, 0, 0)
        val title = "From " + t.inst + (if (info.name.isNotBlank()) "  -  " + info.name else "")
        col.addView(Ui.text(this, title, 16f, color, true))
        if (info.module.isNotBlank()) col.addView(Ui.text(this, "Module: " + info.module, 12f, Ui.INK))
        col.addView(Ui.text(this, "Deleted " + Ui.ago(t.file.lastModified()), 12f, Ui.GREY))
        col.addView(Ui.text(this, "Auto-removed in " + Store.daysLeft(t) + " day(s)", 12f, Ui.GREY))
        top.addView(col)
        box.addView(top)

        val row = LinearLayout(this)
        row.setPadding(0, dp(12), 0, 0)
        row.addView(Ui.button(this, "Restore", color, Color.WHITE) {
            val f = Store.restore(this, t)
            Toast.makeText(this, "Restored to " + t.inst + " as " + f.name, Toast.LENGTH_SHORT).show()
            render()
        }, Ui.weight(this))
        row.addView(Ui.button(this, "Delete forever", 0x1ADC2626, Ui.RED) {
            AlertDialog.Builder(this)
                .setTitle("Delete forever?")
                .setMessage("This picture cannot be recovered.")
                .setPositiveButton("Delete") { _, _ -> Store.deleteForever(t); render() }
                .setNegativeButton("Cancel", null)
                .show()
        }, Ui.weight(this))
        box.addView(row)
        return box
    }
}
