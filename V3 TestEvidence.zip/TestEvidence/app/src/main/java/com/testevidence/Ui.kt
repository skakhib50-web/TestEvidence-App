package com.testevidence

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.util.LruCache
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

object Ui {
    val BG = 0xFFF1F4F9.toInt()
    val INK = 0xFF111827.toInt()
    val GREY = 0xFF6B7280.toInt()
    val LINE = 0xFFE5E9F0.toInt()
    val PRIMARY = 0xFF1565C0.toInt()
    val NAVY = 0xFF0B1F44.toInt()
    val RED = 0xFFDC2626.toInt()
    val GREEN = 0xFF16A34A.toInt()
    val WHITE = 0xFFFFFFFF.toInt()
    val pool: ExecutorService = Executors.newFixedThreadPool(2)

    private val cache = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun colorFor(inst: String): Int = when (inst) {
        "C1" -> 0xFF2563EB.toInt()
        "C2" -> 0xFF059669.toInt()
        else -> 0xFFEA580C.toInt()
    }

    fun tint(color: Int): Int = (color and 0x00FFFFFF) or 0x1F000000

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(c: Context, color: Int, radiusDp: Int, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(c, radiusDp).toFloat()
        if (stroke != 0 && strokeDp > 0) g.setStroke(dp(c, strokeDp), stroke)
        return g
    }

    fun text(c: Context, s: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = s
        t.textSize = sizeSp
        t.setTextColor(color)
        t.typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
        t.letterSpacing = 0.01f
        return t
    }

    fun button(
        c: Context, s: String, bg: Int, fg: Int, stroke: Int = 0, sizeSp: Float = 13f, onClick: () -> Unit
    ): TextView {
        val t = TextView(c)
        t.text = s
        t.textSize = sizeSp
        t.setTextColor(fg)
        t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.setPadding(dp(c, 8), dp(c, 12), dp(c, 8), dp(c, 12))
        t.background = RippleDrawable(ColorStateList.valueOf(0x33000000), rounded(c, bg, 14, stroke, 1), null)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        t.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
        return t
    }

    fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT) =
        LinearLayout.LayoutParams(w, h)

    fun weight(c: Context, marginDp: Int = 3): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        p.setMargins(dp(c, marginDp), 0, dp(c, marginDp), 0)
        return p
    }

    fun fadeIn(v: View, delay: Long) {
        v.alpha = 0f
        v.translationY = dp(v.context, 14).toFloat()
        v.animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(260).start()
    }

    fun thumb(f: File, target: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= target && o.outHeight / (s * 2) >= target) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    fun loadInto(iv: ImageView, f: File, target: Int = 240) {
        val key = f.path + "@" + f.lastModified() + "@" + target
        val hit = cache.get(key)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        pool.execute {
            val bm = thumb(f, target)
            if (bm != null) cache.put(key, bm)
            iv.post { iv.setImageBitmap(bm) }
        }
    }

    fun ago(ms: Long): String {
        val m = (System.currentTimeMillis() - ms) / 60000
        return when {
            m < 1 -> "just now"
            m < 60 -> "$m min ago"
            m < 1440 -> "${m / 60} h ago"
            else -> "${m / 1440} d ago"
        }
    }
}
