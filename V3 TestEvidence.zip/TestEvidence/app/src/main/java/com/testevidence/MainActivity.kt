package com.testevidence

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.content.res.ColorStateList
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private var animated = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { render() }
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.NAVY
        Thread { Store.purgeOld(this) }.start()
        render()
    }

    override fun onResume() {
        super.onResume()
        ContextCompat.registerReceiver(
            this, receiver, IntentFilter(ScreenshotService.ACTION_UPDATED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        render()
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    private fun cardBox(): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(16), dp(16), dp(16))
        box.background = Ui.rounded(this, Color.WHITE, 22)
        box.elevation = dp(3).toFloat()
        box.layoutParams = Ui.lp().apply { topMargin = dp(14) }
        return box
    }

    private fun render() {
        val running = Store.running(this)
        val active = Store.active(this)

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setBackgroundColor(Ui.BG)

        // ---------- header ----------
        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(22), dp(38), dp(22), dp(26))
        val hb = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Ui.NAVY, Ui.PRIMARY))
        val r = dp(32).toFloat()
        hb.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        header.background = hb
        header.elevation = dp(6).toFloat()
        header.addView(Ui.text(this, "Test Evidence", 28f, Color.WHITE, true))
        val sub = Ui.text(this, "Screenshots sorted automatically into C1 · C2 · C3", 13f, 0xCCFFFFFF.toInt())
        sub.setPadding(0, dp(4), 0, dp(16))
        header.addView(sub)

        val bubble = Ui.text(
            this,
            if (running) "●  ON   |   Capturing to $active" else "●  OFF   |   Not capturing",
            14f, Color.WHITE, true
        )
        bubble.setPadding(dp(18), dp(10), dp(18), dp(10))
        bubble.background = Ui.rounded(this, if (running) Ui.GREEN else Ui.RED, 26, 0x55FFFFFF, 2)
        bubble.elevation = dp(4).toFloat()
        header.addView(bubble, Ui.lp().apply { width = LinearLayout.LayoutParams.WRAP_CONTENT })

        header.addView(
            Ui.button(
                this,
                if (running) "Turn OFF  -  stop capturing" else "Turn ON  -  start capturing",
                Color.WHITE, if (running) Ui.RED else Ui.GREEN, 0, 16f
            ) { if (running) stopCapture() else startCapture() },
            Ui.lp().apply { topMargin = dp(18) }
        )
        page.addView(header)

        // ---------- body ----------
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(16), dp(2), dp(16), dp(30))

        body.addView(moduleCard())
        Store.INSTANCES.forEach { body.addView(card(it, it == active)) }
        body.addView(
            Ui.button(this, "Export ALL instances (Zip / Word)", Ui.PRIMARY, Color.WHITE, 0, 15f) {
                Exporter.ask(this, Store.INSTANCES)
            },
            Ui.lp().apply { topMargin = dp(20) }
        )
        val tc = Store.trash(this).size
        body.addView(
            Ui.button(this, "Recently deleted ($tc)", Color.WHITE, Ui.PRIMARY, Ui.PRIMARY, 14f) {
                startActivity(Intent(this, TrashActivity::class.java))
            },
            Ui.lp().apply { topMargin = dp(10) }
        )
        body.addView(optionsCard())
        page.addView(body)

        if (!animated) {
            for (i in 0 until body.childCount) Ui.fadeIn(body.getChildAt(i), 60L * i)
            animated = true
        }

        val sv = ScrollView(this)
        sv.setBackgroundColor(Ui.BG)
        sv.isFillViewport = true
        sv.addView(page)
        setContentView(sv)
    }

    private fun moduleCard(): View {
        val mod = Store.currentModule(this)
        val box = cardBox()
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        col.addView(Ui.text(this, "CURRENT MODULE", 11f, Ui.GREY, true))
        col.addView(
            Ui.text(this, if (mod.isEmpty()) "None (screenshots not tagged)" else mod, 18f, if (mod.isEmpty()) Ui.GREY else Ui.INK, true)
        )
        row.addView(col)
        row.addView(Ui.button(this, if (mod.isEmpty()) "Set" else "Change", Ui.tint(Ui.PRIMARY), Ui.PRIMARY) { moduleDialog() },
            Ui.lp(w = LinearLayout.LayoutParams.WRAP_CONTENT))
        box.addView(row)
        return box
    }

    private fun moduleDialog() {
        val et = AutoCompleteTextView(this)
        et.hint = "Module name, e.g. Login"
        et.setSingleLine()
        et.setText(Store.currentModule(this))
        et.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, Store.allModules(this)))
        et.threshold = 0
        et.setOnClickListener { et.showDropDown() }
        val box = LinearLayout(this)
        box.setPadding(dp(22), dp(10), dp(22), 0)
        box.addView(et, Ui.lp())
        AlertDialog.Builder(this)
            .setTitle("Module for new screenshots")
            .setMessage("Every screenshot you take next will be tagged with this module.")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                Store.setCurrentModule(this, et.text.toString())
                refreshService()
                render()
            }
            .setNeutralButton("No module") { _, _ ->
                Store.setCurrentModule(this, "")
                refreshService()
                render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun refreshService() {
        if (Store.running(this)) {
            startService(Intent(this, ScreenshotService::class.java).setAction(ScreenshotService.ACTION_SWITCH))
        }
    }

    private fun card(inst: String, isActive: Boolean): View {
        val files = Store.files(this, inst)
        val color = Ui.colorFor(inst)
        val mods = Store.modules(this, inst).size

        val box = cardBox()
        box.background = Ui.rounded(this, Color.WHITE, 22, if (isActive) color else Color.WHITE, if (isActive) 2 else 0)

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        val iv = ImageView(this)
        iv.layoutParams = LinearLayout.LayoutParams(dp(68), dp(68))
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.background = Ui.rounded(this, Ui.tint(color), 16)
        iv.clipToOutline = true
        if (files.isNotEmpty()) Ui.loadInto(iv, files.last())
        top.addView(iv)

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        info.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        info.setPadding(dp(14), 0, 0, 0)
        info.addView(Ui.text(this, inst, 24f, color, true))
        val line = files.size.toString() + (if (files.size == 1) " screenshot" else " screenshots") +
            (if (mods > 0) "  ·  $mods module" + (if (mods == 1) "" else "s") else "")
        info.addView(Ui.text(this, line, 13f, Ui.GREY))
        top.addView(info)

        if (isActive) {
            val chip = Ui.text(this, "ACTIVE", 11f, Color.WHITE, true)
            chip.setPadding(dp(12), dp(5), dp(12), dp(5))
            chip.background = Ui.rounded(this, color, 20)
            top.addView(chip)
        }
        box.addView(top)

        val row = LinearLayout(this)
        row.setPadding(0, dp(14), 0, 0)
        row.addView(Ui.button(this, if (isActive) "Active ✓" else "Use", Ui.tint(color), color) { setActive(inst) }, Ui.weight(this))
        row.addView(Ui.button(this, "Open", Color.WHITE, color, color) {
            startActivity(Intent(this, ManageActivity::class.java).putExtra("inst", inst))
        }, Ui.weight(this))
        row.addView(Ui.button(this, "Export", color, Color.WHITE) { Exporter.ask(this, listOf(inst)) }, Ui.weight(this))
        box.addView(row)
        return box
    }

    private fun seek(max: Int, progress: Int, onChange: (Int) -> Unit): SeekBar {
        val sb = SeekBar(this)
        sb.max = max
        sb.progress = progress
        sb.progressTintList = ColorStateList.valueOf(Ui.PRIMARY)
        sb.thumbTintList = ColorStateList.valueOf(Ui.PRIMARY)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { onChange(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        return sb
    }

    private fun optionsCard(): View {
        val box = cardBox()
        box.addView(Ui.text(this, "OPTIONS", 11f, Ui.GREY, true))

        // ---- floating button on/off ----
        val on = Store.bubbleEnabled(this)
        val a11y = Store.a11yEnabled(this)
        val row1 = LinearLayout(this)
        row1.gravity = Gravity.CENTER_VERTICAL
        row1.setPadding(0, dp(8), 0, 0)
        val col1 = LinearLayout(this)
        col1.orientation = LinearLayout.VERTICAL
        col1.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        col1.addView(Ui.text(this, "Floating capture button", 16f, Ui.INK, true))
        col1.addView(Ui.text(this,
            if (!a11y) "Needs a one-time permission (below)" else if (on) "Shows a transparent circle while capturing is ON" else "Hidden",
            12f, if (!a11y) Ui.RED else Ui.GREY))
        row1.addView(col1)
        row1.addView(Ui.button(this, if (on) "ON" else "OFF", if (on) Ui.GREEN else Ui.RED, Color.WHITE) {
            Store.setBubbleEnabled(this, !on)
            CaptureAccessibilityService.instance?.refreshOverlay()
            render()
        }, Ui.lp(w = dp(72)))
        box.addView(row1)

        if (!a11y) {
            val help = Ui.text(this,
                "Step 1: tap \"Accessibility settings\", find Test Evidence and turn it ON.\n" +
                    "If Android says \"Restricted setting\": tap \"App info\", press the ⋮ menu (top right) → Allow restricted settings, then repeat step 1.\n" +
                    "It is only used to take a screenshot when you tap the circle.",
                12f, Ui.GREY)
            help.setPadding(0, dp(10), 0, dp(8))
            box.addView(help)
            val hr = LinearLayout(this)
            hr.addView(Ui.button(this, "Accessibility settings", Ui.PRIMARY, Color.WHITE) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }, Ui.weight(this))
            hr.addView(Ui.button(this, "App info", Color.WHITE, Ui.PRIMARY, Ui.PRIMARY) {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName))
                )
            }, Ui.weight(this))
            box.addView(hr)
        }

        // ---- live preview ----
        val sizeDp = Store.bubbleDp(this)
        val opacity = Store.bubbleOpacity(this)
        val holder = FrameLayout(this)
        holder.background = Ui.rounded(this, 0xFF1F2937.toInt(), 16)
        val hLp = Ui.lp(h = dp(130))
        hLp.topMargin = dp(14)
        val preview = BubbleView(this)
        holder.addView(preview, FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp), Gravity.CENTER))
        preview.alpha = opacity / 100f
        box.addView(holder, hLp)

        // ---- size slider ----
        val sizeLbl = Ui.text(this, "Size:  $sizeDp dp", 14f, Ui.INK, true)
        sizeLbl.setPadding(0, dp(12), 0, 0)
        box.addView(sizeLbl)
        box.addView(seek(84, sizeDp - 36) { p ->
            val v = p + 36
            Store.setBubbleDp(this, v)
            sizeLbl.text = "Size:  $v dp"
            preview.layoutParams = FrameLayout.LayoutParams(dp(v), dp(v), Gravity.CENTER)
            CaptureAccessibilityService.instance?.refreshOverlay()
        })

        // ---- opacity slider ----
        val opLbl = Ui.text(this, "Transparency:  $opacity% visible", 14f, Ui.INK, true)
        opLbl.setPadding(0, dp(8), 0, 0)
        box.addView(opLbl)
        box.addView(seek(75, opacity - 25) { p ->
            val v = p + 25
            Store.setBubbleOpacity(this, v)
            opLbl.text = "Transparency:  $v% visible"
            preview.alpha = v / 100f
            CaptureAccessibilityService.instance?.refreshOverlay()
        })

        // ---- battery saver ----
        val m = Store.idleMinutes(this)
        val label = if (m == 0) "Off" else if (m < 60) "$m min" else (m / 60).toString() + " h"
        val row3 = LinearLayout(this)
        row3.gravity = Gravity.CENTER_VERTICAL
        row3.setPadding(0, dp(16), 0, 0)
        val col3 = LinearLayout(this)
        col3.orientation = LinearLayout.VERTICAL
        col3.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        col3.addView(Ui.text(this, "Battery saver", 16f, Ui.INK, true))
        col3.addView(Ui.text(this, "Auto turn OFF after $label with no screenshots", 12f, Ui.GREY))
        row3.addView(col3)
        row3.addView(Ui.button(this, "Change", Ui.tint(Ui.PRIMARY), Ui.PRIMARY) {
            val opts = listOf(0, 30, 60, 120, 240)
            Store.setIdleMinutes(this, opts[(opts.indexOf(m).coerceAtLeast(0) + 1) % opts.size])
            refreshService()
            render()
        }, Ui.lp(w = LinearLayout.LayoutParams.WRAP_CONTENT))
        box.addView(row3)
        return box
    }

    private fun setActive(inst: String) {
        Store.setActive(this, inst)
        if (Store.running(this)) {
            startService(
                Intent(this, ScreenshotService::class.java)
                    .setAction(ScreenshotService.ACTION_SWITCH).putExtra("inst", inst)
            )
        }
        render()
    }

    private fun mediaPerm() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun startCapture() {
        val need = ArrayList<String>()
        if (checkSelfPermission(mediaPerm()) != PackageManager.PERMISSION_GRANTED) need.add(mediaPerm())
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT < 30 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), 1); return }
        proceedAfterPerms()
    }

    private fun proceedAfterPerms() {
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            toast("Turn ON \"Allow access to manage all files\" for this app, then come back and tap Turn ON again.")
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + packageName))
            )
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, ScreenshotService::class.java))
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(mediaPerm()) == PackageManager.PERMISSION_GRANTED) proceedAfterPerms()
        else toast("Photos access (Allow all) is needed to detect screenshots")
    }

    private fun stopCapture() {
        startService(Intent(this, ScreenshotService::class.java).setAction(ScreenshotService.ACTION_STOP))
        Store.setRunning(this, false)
        render()
    }
}
