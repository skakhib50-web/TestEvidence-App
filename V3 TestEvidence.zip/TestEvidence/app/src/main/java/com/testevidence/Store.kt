package com.testevidence

import android.app.Activity
import android.app.ActivityManager
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object Store {
    val INSTANCES = listOf("C1", "C2", "C3")

    private fun p(c: Context) = c.getSharedPreferences("te", Context.MODE_PRIVATE)

    fun active(c: Context): String = p(c).getString("active", "C1") ?: "C1"
    fun setActive(c: Context, i: String) = p(c).edit().putString("active", i).apply()
    fun lastId(c: Context): Long = p(c).getLong("lastId", 0L)
    fun setLastId(c: Context, v: Long) = p(c).edit().putLong("lastId", v).apply()
    fun currentModule(c: Context): String = p(c).getString("module", "") ?: ""
    fun setCurrentModule(c: Context, m: String) = p(c).edit().putString("module", clean(m)).apply()
    fun idleMinutes(c: Context): Int = p(c).getInt("idleMin", 120)
    fun setIdleMinutes(c: Context, v: Int) = p(c).edit().putInt("idleMin", v).apply()
    fun setRunning(c: Context, v: Boolean) = p(c).edit().putBoolean("running", v).apply()

    // floating button settings
    fun bubbleEnabled(c: Context): Boolean = p(c).getBoolean("bubbleOn", true)
    fun setBubbleEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("bubbleOn", v).apply()
    fun bubbleDp(c: Context): Int = p(c).getInt("bubbleDp", 56)
    fun setBubbleDp(c: Context, v: Int) = p(c).edit().putInt("bubbleDp", v).apply()
    fun bubbleOpacity(c: Context): Int = p(c).getInt("bubbleOp", 70)
    fun setBubbleOpacity(c: Context, v: Int) = p(c).edit().putInt("bubbleOp", v).apply()
    fun bubbleX(c: Context, def: Int): Int = p(c).getInt("bx", -1).let { if (it < 0) def else it }
    fun bubbleY(c: Context, def: Int): Int = p(c).getInt("by", -1).let { if (it < 0) def else it }
    fun setBubblePos(c: Context, x: Int, y: Int) = p(c).edit().putInt("bx", x).putInt("by", y).apply()

    fun a11yEnabled(c: Context): Boolean {
        val v = android.provider.Settings.Secure.getString(
            c.contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return v.contains(c.packageName + "/") && v.contains("CaptureAccessibilityService")
    }

    /** ON only when the flag is set AND the service is really alive. */
    fun running(c: Context): Boolean {
        if (!p(c).getBoolean("running", false)) return false
        return try {
            val am = c.getSystemService(ActivityManager::class.java)
            @Suppress("DEPRECATION")
            am.getRunningServices(100).any { it.service.className == ScreenshotService::class.java.name }
        } catch (e: Exception) { true }
    }

    // ---------- folders ----------
    fun root(c: Context): File {
        val base = c.getExternalFilesDir(null) ?: c.filesDir
        return File(base, "TestEvidence").also { it.mkdirs() }
    }

    fun dir(c: Context, inst: String): File = File(root(c), inst).also { it.mkdirs() }

    fun files(c: Context, inst: String): List<File> =
        dir(c, inst).listFiles()?.filter { it.isFile && !it.name.startsWith(".") }?.sortedBy { it.name }
            ?: emptyList()

    // ---------- file name = INST_NNN[__module[__name]].ext ----------
    private val nameRe = Regex("^([A-Za-z0-9]+)_(\\d+)((?:__[^.]*)?)\\.([A-Za-z0-9]+)$")
    private val trashRe = Regex("^\\d+((?:__[^.]*)?)\\.([A-Za-z0-9]+)$")
    private val numRe = Regex("^[A-Za-z0-9]+_(\\d+)")
    private val badChars = Regex("[^\\p{L}\\p{N} \\-()]")

    data class Info(val file: File, val num: Int, val module: String, val name: String)

    fun clean(s: String): String =
        s.replace(badChars, "").replace(Regex(" +"), " ").trim().take(40)

    fun suffixFor(module: String, name: String): String {
        val m = clean(module)
        val n = clean(name)
        if (m.isEmpty() && n.isEmpty()) return ""
        return "__" + m + (if (n.isEmpty()) "" else "__" + n)
    }

    fun info(f: File): Info {
        val m = nameRe.find(f.name) ?: return Info(f, 0, "", "")
        val parts = m.groupValues[3].split("__").drop(1)
        return Info(f, m.groupValues[2].toIntOrNull() ?: 0, parts.getOrElse(0) { "" }, parts.getOrElse(1) { "" })
    }

    fun caption(f: File): String {
        val m = nameRe.find(f.name)
        val i = info(f)
        val base = if (m != null) m.groupValues[1] + "-" + m.groupValues[2] else f.nameWithoutExtension
        return if (i.name.isNotBlank()) base + "  -  " + i.name else base
    }

    fun modules(c: Context, inst: String): List<String> =
        files(c, inst).map { info(it).module }.filter { it.isNotBlank() }.distinct()

    fun allModules(c: Context): List<String> = INSTANCES.flatMap { modules(c, it) }.distinct()

    fun nextFile(c: Context, inst: String, ext: String, suffix: String = ""): File {
        val max = files(c, inst).maxOfOrNull { numRe.find(it.name)?.groupValues?.get(1)?.toIntOrNull() ?: 0 } ?: 0
        return File(dir(c, inst), String.format(Locale.US, "%s_%03d%s.%s", inst, max + 1, suffix, ext))
    }

    /** Renames the given files, in the given order, to INST_001, INST_002, ... keeping module/name. */
    fun renumber(c: Context, inst: String, ordered: List<File>) {
        val d = dir(c, inst)
        val temps = ordered.mapIndexed { i, f ->
            val t = File(d, ".tmp_$i")
            val sfx = nameRe.find(f.name)?.groupValues?.get(3) ?: ""
            f.renameTo(t)
            Triple(t, sfx, f.extension)
        }
        temps.forEachIndexed { i, tr ->
            tr.first.renameTo(File(d, String.format(Locale.US, "%s_%03d%s.%s", inst, i + 1, tr.second, tr.third)))
        }
    }

    fun rename(c: Context, inst: String, f: File, name: String, module: String): File? {
        val m = nameRe.find(f.name) ?: return null
        val dest = File(
            f.parentFile,
            m.groupValues[1] + "_" + m.groupValues[2] + suffixFor(module, name) + "." + m.groupValues[4]
        )
        if (dest.name == f.name) return f
        return if (f.renameTo(dest)) dest else null
    }

    fun groups(c: Context, inst: String): List<Pair<String, List<File>>> {
        val map = LinkedHashMap<String, MutableList<File>>()
        files(c, inst).forEach { map.getOrPut(info(it).module) { mutableListOf() }.add(it) }
        return map.entries.map { Pair(it.key, it.value as List<File>) }
    }

    // ---------- Recently deleted ----------
    data class TrashItem(val inst: String, val file: File)

    const val TRASH_DAYS = 7
    private const val DAY_MS = 86_400_000L

    private fun trashDir(c: Context, inst: String): File =
        File(root(c), "_trash/" + inst).also { it.mkdirs() }

    private fun moveFile(from: File, to: File) {
        if (!from.renameTo(to)) {
            from.copyTo(to, true)
            from.delete()
        }
    }

    private fun toTrash(c: Context, inst: String, f: File) {
        val sfx = nameRe.find(f.name)?.groupValues?.get(3) ?: ""
        val dest = File(trashDir(c, inst), System.nanoTime().toString() + sfx + "." + f.extension)
        moveFile(f, dest)
        dest.setLastModified(System.currentTimeMillis())
    }

    fun delete(c: Context, inst: String, f: File) {
        toTrash(c, inst, f)
        renumber(c, inst, files(c, inst))
    }

    fun clear(c: Context, inst: String) {
        files(c, inst).forEach { toTrash(c, inst, it) }
    }

    fun trash(c: Context): List<TrashItem> =
        INSTANCES.flatMap { inst ->
            (trashDir(c, inst).listFiles()?.filter { it.isFile } ?: emptyList()).map { TrashItem(inst, it) }
        }.sortedByDescending { it.file.lastModified() }

    fun trashInfo(t: TrashItem): Info {
        val m = trashRe.find(t.file.name) ?: return Info(t.file, 0, "", "")
        val parts = m.groupValues[1].split("__").drop(1)
        return Info(t.file, 0, parts.getOrElse(0) { "" }, parts.getOrElse(1) { "" })
    }

    fun restore(c: Context, t: TrashItem): File {
        val sfx = trashRe.find(t.file.name)?.groupValues?.get(1) ?: ""
        val dest = nextFile(c, t.inst, t.file.extension, sfx)
        moveFile(t.file, dest)
        return dest
    }

    fun deleteForever(t: TrashItem) { t.file.delete() }

    fun emptyTrash(c: Context) { trash(c).forEach { it.file.delete() } }

    fun daysLeft(t: TrashItem): Int {
        val left = t.file.lastModified() + TRASH_DAYS * DAY_MS - System.currentTimeMillis()
        return ((left + DAY_MS - 1) / DAY_MS).toInt().coerceAtLeast(0)
    }

    fun purgeOld(c: Context) {
        val cutoff = System.currentTimeMillis() - TRASH_DAYS * DAY_MS
        trash(c).filter { it.file.lastModified() < cutoff }.forEach { it.file.delete() }
    }

    // ---------- export ----------
    fun exportDir(c: Context): File = File(root(c), "_zips").also { it.mkdirs() }

    fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())

    fun zip(c: Context, inst: String): File? {
        val gs = groups(c, inst)
        if (gs.isEmpty()) return null
        val zd = exportDir(c)
        zd.listFiles()?.filter { it.name.startsWith(inst + "_") && it.extension == "zip" }?.forEach { it.delete() }
        val out = File(zd, inst + "_" + stamp() + ".zip")
        ZipOutputStream(out.outputStream().buffered()).use { z ->
            gs.forEach { g ->
                g.second.forEach { f ->
                    val entry = if (g.first.isBlank()) f.name else g.first + "/" + f.name
                    z.putNextEntry(ZipEntry(entry))
                    f.inputStream().use { it.copyTo(z) }
                    z.closeEntry()
                }
            }
        }
        return out
    }

    fun uriFor(c: Context, f: File): Uri =
        FileProvider.getUriForFile(c, c.packageName + ".fileprovider", f)

    fun shareFiles(act: Activity, list: List<File>) {
        val uris = ArrayList(list.map { uriFor(act, it) })
        val i = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        val exts = list.map { it.extension }.distinct()
        i.type = when {
            exts == listOf("zip") -> "application/zip"
            exts == listOf("docx") -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            else -> "*/*"
        }
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val clip = ClipData.newRawUri("files", uris[0])
        for (k in 1 until uris.size) clip.addItem(ClipData.Item(uris[k]))
        i.clipData = clip
        act.startActivity(Intent.createChooser(i, "Share"))
    }
}
