plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.testevidence"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.testevidence"
        minSdk = 26
        targetSdk = 34
        versionCode = 6
        versionName = "1.5"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    flavorDimensions += "edition"
    productFlavors {
        create("safe") {
            dimension = "edition"
            resValue("string", "app_name", "Test Evidence")
        }
        create("circle") {
            dimension = "edition"
            applicationIdSuffix = ".circle"
            versionNameSuffix = "-circle"
            resValue("string", "app_name", "Test Evidence Circle")
        }
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
