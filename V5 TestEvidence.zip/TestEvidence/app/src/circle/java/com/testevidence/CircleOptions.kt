package com.testevidence

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.provider.Settings
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar

object CircleOptions {
    const val AVAILABLE = true

    fun a11yReady(c: Context): Boolean = Store.a11yEnabled(c)

    fun openA11y(act: Activity) {
        try {
            val i = Intent("android.settings.ACCESSIBILITY_DETAILS_SETTINGS")
            i.putExtra("android.intent.extra.COMPONENT_NAME",
                ComponentName(act, CaptureAccessibilityService::class.java).flattenToString())
            act.startActivity(i)
            return
        } catch (e: Exception) {
            // older Android: fall back to the list
        }
        act.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun seek(act: Activity, max: Int, progress: Int, onChange: (Int) -> Unit): SeekBar {
        val sb = SeekBar(act)
        sb.max = max
        sb.progress = progress
        sb.progressTintList = ColorStateList.valueOf(Ui.PRIMARY)
        sb.thumbTintList = ColorStateList.valueOf(Ui.PRIMARY)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { onChange(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        return sb
    }

    fun addOptions(act: Activity, box: LinearLayout, rerender: () -> Unit) {
        fun dp(v: Int) = Ui.dp(act, v)
        val on = Store.bubbleEnabled(act)
        val a11y = Store.a11yEnabled(act)

        val row1 = LinearLayout(act)
        row1.gravity = Gravity.CENTER_VERTICAL
        row1.setPadding(0, dp(14), 0, 0)
        val col1 = LinearLayout(act)
        col1.orientation = LinearLayout.VERTICAL
        col1.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        col1.addView(Ui.text(act, "Floating capture button", 16f, Ui.INK, true))
        col1.addView(Ui.text(act,
            if (!a11y) "Needs one-time permission (use the Setup guide)" else if (on) "Transparent circle shows while capturing is ON" else "Hidden",
            12f, if (!a11y) Ui.RED else Ui.GREY))
        row1.addView(col1)
        row1.addView(Ui.button(act, if (on) "ON" else "OFF", if (on) Ui.GREEN else Ui.RED, Color.WHITE) {
            Store.setBubbleEnabled(act, !on)
            CaptureAccessibilityService.instance?.refreshOverlay()
            rerender()
        }, Ui.lp(w = dp(72)))
        box.addView(row1)

        val sizeDp = Store.bubbleDp(act)
        val opacity = Store.bubbleOpacity(act)
        val holder = FrameLayout(act)
        holder.background = Ui.rounded(act, 0xFF1F2937.toInt(), 16)
        val hLp = Ui.lp(h = dp(130))
        hLp.topMargin = dp(14)
        val preview = BubbleView(act)
        holder.addView(preview, FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp), Gravity.CENTER))
        preview.alpha = opacity / 100f
        box.addView(holder, hLp)

        val sizeLbl = Ui.text(act, "Size:  $sizeDp dp", 14f, Ui.INK, true)
        sizeLbl.setPadding(0, dp(12), 0, 0)
        box.addView(sizeLbl)
        box.addView(seek(act, 84, sizeDp - 36) { p ->
            val v = p + 36
            Store.setBubbleDp(act, v)
            sizeLbl.text = "Size:  $v dp"
            preview.layoutParams = FrameLayout.LayoutParams(dp(v), dp(v), Gravity.CENTER)
            CaptureAccessibilityService.instance?.refreshOverlay()
        })

        val opLbl = Ui.text(act, "Transparency:  $opacity% visible", 14f, Ui.INK, true)
        opLbl.setPadding(0, dp(8), 0, 0)
        box.addView(opLbl)
        box.addView(seek(act, 75, opacity - 25) { p ->
            val v = p + 25
            Store.setBubbleOpacity(act, v)
            opLbl.text = "Transparency:  $v% visible"
            preview.alpha = v / 100f
            CaptureAccessibilityService.instance?.refreshOverlay()
        })
    }

    @Suppress("unused")
    private fun appInfoUri(c: Context): Uri = Uri.parse("package:" + c.packageName)
}
