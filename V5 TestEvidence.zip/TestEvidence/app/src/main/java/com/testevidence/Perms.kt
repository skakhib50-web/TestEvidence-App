package com.testevidence

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings

object Perms {
    fun mediaPerm(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun photoRequest(): Array<String> =
        if (Build.VERSION.SDK_INT < 30) arrayOf(mediaPerm(), Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else arrayOf(mediaPerm())

    private fun has(c: Context, p: String) = c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun photosOk(c: Context): Boolean = photoRequest().all { has(c, it) }

    fun notifOk(c: Context): Boolean =
        Build.VERSION.SDK_INT < 33 || has(c, Manifest.permission.POST_NOTIFICATIONS)

    fun requiredReady(c: Context): Boolean = photosOk(c) && notifOk(c)

    fun stepsLeft(c: Context): Int = (if (photosOk(c)) 0 else 1) + (if (notifOk(c)) 0 else 1)

    fun openAppInfo(act: Activity) {
        act.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + act.packageName))
        )
    }
}
