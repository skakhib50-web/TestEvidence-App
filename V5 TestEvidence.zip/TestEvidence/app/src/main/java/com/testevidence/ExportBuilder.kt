package com.testevidence

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ExportBuilder {
    private const val MAX_SIDE = 1600

    private fun load(f: File): Img? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var s = 1
        while (maxOf(o.outWidth, o.outHeight) / (s * 2) >= MAX_SIDE) s *= 2
        var bm = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
        val big = maxOf(bm.width, bm.height)
        if (big > MAX_SIDE) {
            val k = MAX_SIDE.toFloat() / big
            val sc = Bitmap.createScaledBitmap(
                bm, (bm.width * k).toInt().coerceAtLeast(1), (bm.height * k).toInt().coerceAtLeast(1), true
            )
            if (sc !== bm) { bm.recycle(); bm = sc }
        }
        val bos = ByteArrayOutputStream()
        bm.compress(Bitmap.CompressFormat.JPEG, 85, bos)
        val r = Img(bos.toByteArray(), bm.width, bm.height)
        bm.recycle()
        return r
    }

    private fun groups(c: Context, inst: String): List<OfficeGroup> =
        Store.groups(c, inst).map { g -> OfficeGroup(g.first, g.second, g.second.map { Store.caption(it) }) }

    private fun outFile(c: Context, inst: String, ext: String): File {
        val zd = Store.exportDir(c)
        zd.listFiles()?.filter { it.name.startsWith(inst + "_") && it.extension == ext }?.forEach { it.delete() }
        return File(zd, inst + "_" + Store.stamp() + "." + ext)
    }

    private fun now(): String = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US).format(Date())

    fun docx(c: Context, inst: String): File? {
        val gs = groups(c, inst)
        if (gs.isEmpty()) return null
        val out = outFile(c, inst, "docx")
        out.outputStream().use { OfficeWriter.writeDocx(it, "$inst - Test Evidence", "Generated: " + now(), gs, ::load) }
        return out
    }

    fun xlsx(c: Context, inst: String): File? {
        val gs = groups(c, inst)
        if (gs.isEmpty()) return null
        val out = outFile(c, inst, "xlsx")
        out.outputStream().use { OfficeWriter.writeXlsx(it, "$inst - Test Evidence", "Generated: " + now(), gs, ::load) }
        return out
    }
}
