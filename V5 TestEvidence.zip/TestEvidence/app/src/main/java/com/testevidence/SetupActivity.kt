package com.testevidence

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

/** One screen that walks the user through every permission, with live green ticks. */
class SetupActivity : Activity() {

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.NAVY
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Folder.handle(this, requestCode, resultCode, data)
        render()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        render()
        val blocked = perms.any { checkSelfPermission(it) != android.content.pm.PackageManager.PERMISSION_GRANTED &&
            !shouldShowRequestPermissionRationale(it) }
        if (blocked) {
            toast("Android will not ask again. Open Permissions here and switch it ON.")
            Perms.openAppInfo(this)
        }
    }

    private fun step(
        n: Int, title: String, desc: String, done: Boolean, optional: Boolean,
        btn: String, extraBtn: String?, action: () -> Unit, extra: (() -> Unit)?
    ): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(16), dp(16), dp(16))
        box.background = Ui.rounded(this, Color.WHITE, 22, if (done) Ui.GREEN else 0, if (done) 2 else 0)
        box.elevation = dp(3).toFloat()
        box.layoutParams = Ui.lp().apply { topMargin = dp(14) }

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val badge = Ui.text(this, if (done) "✓" else n.toString(), 16f, Color.WHITE, true)
        badge.gravity = Gravity.CENTER
        badge.background = Ui.rounded(this, if (done) Ui.GREEN else if (optional) Ui.GREY else Ui.RED, 18)
        top.addView(badge, LinearLayout.LayoutParams(dp(36), dp(36)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        col.setPadding(dp(12), 0, 0, 0)
        col.addView(Ui.text(this, title, 17f, Ui.INK, true))
        col.addView(Ui.text(this,
            if (done) "Done" else if (optional) "Optional" else "Needed",
            12f, if (done) Ui.GREEN else if (optional) Ui.GREY else Ui.RED, true))
        top.addView(col)
        box.addView(top)

        val d = Ui.text(this, desc, 13f, Ui.GREY)
        d.setPadding(0, dp(10), 0, dp(10))
        box.addView(d)

        val row = LinearLayout(this)
        row.addView(Ui.button(this, if (done) "Open again" else btn, if (done) Ui.tint(Ui.PRIMARY) else Ui.PRIMARY,
            if (done) Ui.PRIMARY else Color.WHITE, 0, 14f) { action() }, Ui.weight(this))
        if (extraBtn != null && extra != null) {
            row.addView(Ui.button(this, extraBtn, Color.WHITE, Ui.PRIMARY, Ui.PRIMARY, 14f) { extra() }, Ui.weight(this))
        }
        box.addView(row)
        return box
    }

    private fun render() {
        val photos = Perms.photosOk(this)
        val notif = Perms.notifOk(this)
        val circle = CircleOptions.AVAILABLE
        val a11y = CircleOptions.a11yReady(this)
        val folder = Folder.has(this)
        val left = Perms.stepsLeft(this)

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setBackgroundColor(Ui.BG)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(22), dp(38), dp(22), dp(24))
        val hb = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Ui.NAVY, Ui.PRIMARY))
        val r = dp(32).toFloat()
        hb.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        header.background = hb
        header.elevation = dp(6).toFloat()
        header.addView(Ui.text(this, "Setup guide", 28f, Color.WHITE, true))
        val sub = Ui.text(
            this,
            if (left == 0) "Everything needed is ON. You are ready." else "$left required step(s) left. Tap the buttons below, one by one.",
            13f, 0xCCFFFFFF.toInt()
        )
        sub.setPadding(0, dp(4), 0, 0)
        header.addView(sub)
        page.addView(header)

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(16), dp(0), dp(16), dp(28))

        body.addView(step(
            1, "Allow photos", 
            "The app needs this to find the screenshots you take. When Android asks, tap Allow (choose \"Allow all\" if it offers a choice).",
            photos, false, "Allow photos", null,
            { requestPermissions(Perms.photoRequest(), 21) }, null
        ))
        body.addView(step(
            2, "Allow notifications",
            "Shows the ON state, the C1 / C2 / C3 switch buttons and the quick \"Name it\" banner after each screenshot.",
            notif, false, "Allow notifications", null,
            {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 22)
                else toast("Notifications are already allowed on this Android version")
            }, null
        ))
        var n = 3
        if (circle) {
            body.addView(step(
                n++, "Floating button (Accessibility)",
                "1. Tap \"Open settings\" and turn Test Evidence ON.\n" +
                    "2. If Android says \"Restricted setting\": tap \"App info\", press the ⋮ menu (top right), choose \"Allow restricted settings\", then try step 1 again.\n" +
                    "Used only to take a screenshot when you tap the circle.",
                a11y, false, "Open settings", "App info",
                { CircleOptions.openA11y(this) }, { Perms.openAppInfo(this) }
            ))
        }
        body.addView(step(
            n, "Choose where files are saved",
            "Pick a folder (for example Documents) for your Word, Excel and zip files. Skip it and you can still use Share.\nNow: " + Folder.name(this),
            folder, true, "Choose folder", null,
            { Folder.pick(this) }, null
        ))

        if (left == 0) {
            body.addView(
                Ui.button(this, "All set  -  go to the app", Ui.GREEN, Color.WHITE, 0, 16f) { finish() },
                Ui.lp().apply { topMargin = dp(20) }
            )
        } else {
            body.addView(
                Ui.button(this, "Skip for now", Color.WHITE, Ui.PRIMARY, Ui.PRIMARY, 14f) { finish() },
                Ui.lp().apply { topMargin = dp(20) }
            )
        }
        page.addView(body)

        val sv = ScrollView(this)
        sv.setBackgroundColor(Ui.BG)
        sv.addView(page)
        setContentView(sv)
    }
}
