package com.testevidence

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import java.io.File
import java.util.Collections

class ManageActivity : Activity() {

    private lateinit var inst: String
    private var sv: ScrollView? = null

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        inst = intent.getStringExtra("inst") ?: "C1"
        window.statusBarColor = Ui.colorFor(inst)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Folder.handle(this, requestCode, resultCode, data)
    }

    private fun render() {
        val files = Store.files(this, inst)
        val color = Ui.colorFor(inst)
        val y = sv?.scrollY ?: 0

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setBackgroundColor(Ui.BG)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(22), dp(34), dp(22), dp(22))
        val hb = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(color, (color and 0x00FFFFFF) or 0xFF000000.toInt()))
        hb.colors = intArrayOf(Ui.NAVY, color)
        val r = dp(32).toFloat()
        hb.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        header.background = hb
        header.elevation = dp(6).toFloat()
        val back = Ui.text(this, "‹  Back", 15f, Color.WHITE, true)
        back.setPadding(0, 0, 0, dp(10))
        back.setOnClickListener { finish() }
        header.addView(back)
        header.addView(Ui.text(this, inst, 30f, Color.WHITE, true))
        val mods = Store.modules(this, inst).size
        val sub = Ui.text(
            this,
            files.size.toString() + " screenshot(s)" + (if (mods > 0) "  ·  $mods module(s)" else "") + ".  Tap a picture to view.",
            13f, 0xCCFFFFFF.toInt()
        )
        sub.setPadding(0, dp(2), 0, dp(16))
        header.addView(sub)
        val row = LinearLayout(this)
        row.addView(Ui.button(this, "Export", Color.WHITE, color) { Exporter.ask(this, listOf(inst)) }, Ui.weight(this))
        row.addView(Ui.button(this, "Clear all", 0x33FFFFFF, Color.WHITE) {
            if (files.isEmpty()) return@button
            AlertDialog.Builder(this)
                .setTitle("Clear all of $inst?")
                .setMessage("They move to Recently deleted and can be restored for " + Store.TRASH_DAYS + " days.")
                .setPositiveButton("Clear") { _, _ -> Store.clear(this, inst); render() }
                .setNegativeButton("Cancel", null)
                .show()
        }, Ui.weight(this))
        header.addView(row)
        page.addView(header)

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(11), dp(12), dp(11), dp(26))
        if (files.isEmpty()) {
            val e = Ui.text(this, "No screenshots yet.\nTurn capturing ON and take a screenshot.", 15f, Ui.GREY)
            e.setPadding(dp(8), dp(30), dp(8), 0)
            body.addView(e)
        }
        var i = 0
        while (i < files.size) {
            val line = LinearLayout(this)
            line.addView(cell(files, i, color))
            if (i + 1 < files.size) line.addView(cell(files, i + 1, color))
            else line.addView(View(this), Ui.weight(this, 5))
            body.addView(line)
            i += 2
        }
        page.addView(body)

        val s = ScrollView(this)
        s.setBackgroundColor(Ui.BG)
        s.addView(page)
        sv = s
        setContentView(s)
        s.post { s.scrollTo(0, y) }
    }

    private fun cell(files: List<File>, idx: Int, color: Int): View {
        val f = files[idx]
        val info = Store.info(f)
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.setPadding(dp(9), dp(9), dp(9), dp(9))
        cell.background = Ui.rounded(this, Color.WHITE, 18)
        cell.elevation = dp(3).toFloat()
        cell.layoutParams = Ui.weight(this, 5).apply { topMargin = dp(5); bottomMargin = dp(5) }

        val iv = ImageView(this)
        iv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(180))
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.background = Ui.rounded(this, Ui.tint(color), 12)
        iv.clipToOutline = true
        iv.setOnClickListener { open(f) }
        Ui.loadInto(iv, f, 400)
        cell.addView(iv)

        val title = Ui.text(this, if (info.name.isNotBlank()) info.name else f.nameWithoutExtension, 13f, Ui.INK, true)
        title.setPadding(dp(2), dp(8), 0, 0)
        title.maxLines = 1
        cell.addView(title)

        val modText = Ui.text(this, if (info.module.isNotBlank()) info.module else "No module", 11f,
            if (info.module.isNotBlank()) color else Ui.GREY, true)
        modText.setPadding(dp(2), dp(2), 0, dp(8))
        modText.maxLines = 1
        cell.addView(modText)

        val r1 = LinearLayout(this)
        if (idx > 0) r1.addView(Ui.button(this, "◀", Ui.tint(color), color, 0, 13f) { swap(files, idx, idx - 1) }, Ui.weight(this, 2))
        if (idx < files.size - 1) r1.addView(Ui.button(this, "▶", Ui.tint(color), color, 0, 13f) { swap(files, idx, idx + 1) }, Ui.weight(this, 2))
        cell.addView(r1)

        val r2 = LinearLayout(this)
        r2.setPadding(0, dp(4), 0, 0)
        r2.addView(Ui.button(this, "Rename", Ui.tint(color), color, 0, 12f) { renameDialog(f) }, Ui.weight(this, 2))
        r2.addView(Ui.button(this, "Delete", 0x1ADC2626, Ui.RED, 0, 12f) {
            Store.delete(this, inst, f)
            toast("Moved to Recently deleted")
            render()
        }, Ui.weight(this, 2))
        cell.addView(r2)
        return cell
    }

    private fun renameDialog(f: File) {
        val info = Store.info(f)
        val nameEt = EditText(this)
        nameEt.hint = "Name, e.g. OTP screen"
        nameEt.setSingleLine()
        nameEt.setText(info.name)
        val modEt = AutoCompleteTextView(this)
        modEt.hint = "Module, e.g. Login"
        modEt.setSingleLine()
        modEt.setText(info.module)
        modEt.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, Store.allModules(this)))
        modEt.threshold = 0
        modEt.setOnClickListener { modEt.showDropDown() }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(10), dp(22), 0)
        box.addView(nameEt, Ui.lp())
        box.addView(modEt, Ui.lp())
        AlertDialog.Builder(this)
            .setTitle("Rename / set module")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                if (Store.rename(this, inst, f, nameEt.text.toString(), modEt.text.toString()) == null) toast("Could not rename")
                render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun swap(files: List<File>, a: Int, b: Int) {
        val l = files.toMutableList()
        Collections.swap(l, a, b)
        Store.renumber(this, inst, l)
        render()
    }

    private fun open(f: File) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(Store.uriFor(this, f), "image/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            toast("No app found to open images")
        }
    }
}
