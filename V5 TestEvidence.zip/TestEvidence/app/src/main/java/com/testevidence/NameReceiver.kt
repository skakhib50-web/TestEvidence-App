package com.testevidence

import android.app.NotificationManager
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import java.io.File

/** Receives the typed name from the "Name it" notification reply box. */
class NameReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val path = i.getStringExtra("path") ?: return
        val f = File(path)
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.cancel(f.name.hashCode())
        val typed = RemoteInput.getResultsFromIntent(i)?.getCharSequence("name")?.toString() ?: ""
        val name = Store.clean(typed)
        if (name.isEmpty() || !f.exists()) return
        val inst = f.parentFile?.name ?: return
        val nf = Store.rename(c, inst, f, name, Store.info(f).module)
        Toast.makeText(c, "Saved as " + (nf?.nameWithoutExtension ?: f.nameWithoutExtension), Toast.LENGTH_SHORT).show()
        c.sendBroadcast(Intent(ScreenshotService.ACTION_UPDATED).setPackage(c.packageName))
        ScreenshotService.instance?.refreshNotification()
    }
}
