package com.testevidence

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    companion object { private const val REQ_DELETE = 4108 }

    private var animated = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { render() }
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    private fun openSetup() = startActivity(Intent(this, SetupActivity::class.java))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.NAVY
        Thread { Store.purgeOld(this) }.start()
        if (!Store.setupSeen(this) && !Perms.requiredReady(this)) {
            Store.setSetupSeen(this)
            openSetup()
        }
        render()
    }

    override fun onResume() {
        super.onResume()
        ContextCompat.registerReceiver(
            this, receiver, IntentFilter(ScreenshotService.ACTION_UPDATED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        render()
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (Folder.handle(this, requestCode, resultCode, data)) {
            render()
            return
        }
        if (requestCode == REQ_DELETE) {
            if (resultCode == RESULT_OK) {
                Store.clearPending(this)
                toast("Removed from the gallery")
            }
            render()
        }
    }

    private fun cardBox(): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(16), dp(16), dp(16))
        box.background = Ui.rounded(this, Color.WHITE, 22)
        box.elevation = dp(3).toFloat()
        box.layoutParams = Ui.lp().apply { topMargin = dp(14) }
        return box
    }

    private fun render() {
        val running = Store.running(this)
        val active = Store.active(this)
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "" }

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setBackgroundColor(Ui.BG)

        // ---------- header ----------
        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(22), dp(38), dp(22), dp(26))
        val hb = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Ui.NAVY, Ui.PRIMARY))
        val r = dp(32).toFloat()
        hb.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        header.background = hb
        header.elevation = dp(6).toFloat()
        header.addView(Ui.text(this, "Test Evidence", 28f, Color.WHITE, true))
        val sub = Ui.text(this, "Auto-sorted into C1 · C2 · C3   ·   v$ver", 13f, 0xCCFFFFFF.toInt())
        sub.setPadding(0, dp(4), 0, dp(16))
        header.addView(sub)

        val bubble = Ui.text(
            this,
            if (running) "●  ON   |   Capturing to $active" else "●  OFF   |   Not capturing",
            14f, Color.WHITE, true
        )
        bubble.setPadding(dp(18), dp(10), dp(18), dp(10))
        bubble.background = Ui.rounded(this, if (running) Ui.GREEN else Ui.RED, 26, 0x55FFFFFF, 2)
        bubble.elevation = dp(4).toFloat()
        header.addView(bubble, Ui.lp().apply { width = LinearLayout.LayoutParams.WRAP_CONTENT })

        header.addView(
            Ui.button(
                this,
                if (running) "Turn OFF  -  stop capturing" else "Turn ON  -  start capturing",
                Color.WHITE, if (running) Ui.RED else Ui.GREEN, 0, 16f
            ) { if (running) stopCapture() else startCapture() },
            Ui.lp().apply { topMargin = dp(18) }
        )
        page.addView(header)

        // ---------- body ----------
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(16), dp(2), dp(16), dp(30))

        val left = Perms.stepsLeft(this)
        if (left > 0) body.addView(setupBanner(left))
        val cleanup = cleanupCard()
        if (cleanup != null) body.addView(cleanup)

        body.addView(moduleCard())
        Store.INSTANCES.forEach { body.addView(card(it, it == active)) }
        body.addView(
            Ui.button(this, "Export ALL instances", Ui.PRIMARY, Color.WHITE, 0, 15f) {
                Exporter.ask(this, Store.INSTANCES)
            },
            Ui.lp().apply { topMargin = dp(20) }
        )
        val tc = Store.trash(this).size
        body.addView(
            Ui.button(this, "Recently deleted ($tc)", Color.WHITE, Ui.PRIMARY, Ui.PRIMARY, 14f) {
                startActivity(Intent(this, TrashActivity::class.java))
            },
            Ui.lp().apply { topMargin = dp(10) }
        )
        body.addView(optionsCard())
        page.addView(body)

        if (!animated) {
            for (i in 0 until body.childCount) Ui.fadeIn(body.getChildAt(i), 60L * i)
            animated = true
        }

        val sv = ScrollView(this)
        sv.setBackgroundColor(Ui.BG)
        sv.isFillViewport = true
        sv.addView(page)
        setContentView(sv)
    }

    private fun setupBanner(left: Int): View {
        val box = cardBox()
        box.background = Ui.rounded(this, 0xFFFEF2F2.toInt(), 22, Ui.RED, 2)
        box.addView(Ui.text(this, "Finish setup ($left step" + (if (left == 1) "" else "s") + " left)", 17f, Ui.RED, true))
        val d = Ui.text(this, "The app cannot see your screenshots yet. The guide opens each permission screen for you.", 13f, Ui.GREY)
        d.setPadding(0, dp(4), 0, dp(10))
        box.addView(d)
        box.addView(Ui.button(this, "Open setup guide", Ui.RED, Color.WHITE, 0, 14f) { openSetup() })
        return box
    }

    private fun cleanupCard(): View? {
        val uris = Store.pendingUris(this)
        if (uris.isEmpty()) return null
        val box = cardBox()
        box.addView(Ui.text(this, "GALLERY CLEAN-UP", 11f, Ui.GREY, true))
        box.addView(Ui.text(this, uris.size.toString() + " original screenshot(s) are still in your gallery", 15f, Ui.INK, true))
        val d = Ui.text(this, "They are already saved here. Android will ask you once to confirm removing them.", 12f, Ui.GREY)
        d.setPadding(0, dp(2), 0, dp(10))
        box.addView(d)
        box.addView(Ui.button(this, "Remove from gallery", Ui.PRIMARY, Color.WHITE, 0, 14f) { removeFromGallery(uris) })
        return box
    }

    private fun removeFromGallery(uris: List<android.net.Uri>) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val pi = MediaStore.createDeleteRequest(contentResolver, uris)
                startIntentSenderForResult(pi.intentSender, REQ_DELETE, null, 0, 0, 0)
            } else {
                var n = 0
                uris.forEach { n += try { contentResolver.delete(it, null, null) } catch (e: Exception) { 0 } }
                if (n > 0) Store.clearPending(this)
                toast("Removed $n from the gallery")
                render()
            }
        } catch (e: Exception) {
            toast("Could not start the removal: " + e.message)
        }
    }

    private fun moduleCard(): View {
        val mod = Store.currentModule(this)
        val box = cardBox()
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        col.addView(Ui.text(this, "CURRENT MODULE", 11f, Ui.GREY, true))
        col.addView(
            Ui.text(this, if (mod.isEmpty()) "None (screenshots not tagged)" else mod, 18f, if (mod.isEmpty()) Ui.GREY else Ui.INK, true)
        )
        row.addView(col)
        row.addView(Ui.button(this, if (mod.isEmpty()) "Set" else "Change", Ui.tint(Ui.PRIMARY), Ui.PRIMARY) { moduleDialog() },
            Ui.lp(w = LinearLayout.LayoutParams.WRAP_CONTENT))
        box.addView(row)
        return box
    }

    private fun moduleDialog() {
        val et = android.widget.AutoCompleteTextView(this)
        et.hint = "Module name, e.g. Login"
        et.setSingleLine()
        et.setText(Store.currentModule(this))
        et.setAdapter(android.widget.ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, Store.allModules(this)))
        et.threshold = 0
        et.setOnClickListener { et.showDropDown() }
        val box = LinearLayout(this)
        box.setPadding(dp(22), dp(10), dp(22), 0)
        box.addView(et, Ui.lp())
        AlertDialog.Builder(this)
            .setTitle("Module for new screenshots")
            .setMessage("Every screenshot you take next will be tagged with this module.")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                Store.setCurrentModule(this, et.text.toString())
                refreshService()
                render()
            }
            .setNeutralButton("No module") { _, _ ->
                Store.setCurrentModule(this, "")
                refreshService()
                render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun refreshService() {
        if (Store.running(this)) {
            startService(Intent(this, ScreenshotService::class.java).setAction(ScreenshotService.ACTION_SWITCH))
        }
    }

    private fun card(inst: String, isActive: Boolean): View {
        val files = Store.files(this, inst)
        val color = Ui.colorFor(inst)
        val mods = Store.modules(this, inst).size

        val box = cardBox()
        box.background = Ui.rounded(this, Color.WHITE, 22, if (isActive) color else Color.WHITE, if (isActive) 2 else 0)

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        val iv = ImageView(this)
        iv.layoutParams = LinearLayout.LayoutParams(dp(68), dp(68))
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.background = Ui.rounded(this, Ui.tint(color), 16)
        iv.clipToOutline = true
        if (files.isNotEmpty()) Ui.loadInto(iv, files.last())
        top.addView(iv)

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        info.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        info.setPadding(dp(14), 0, 0, 0)
        info.addView(Ui.text(this, inst, 24f, color, true))
        val line = files.size.toString() + (if (files.size == 1) " screenshot" else " screenshots") +
            (if (mods > 0) "  ·  $mods module" + (if (mods == 1) "" else "s") else "")
        info.addView(Ui.text(this, line, 13f, Ui.GREY))
        top.addView(info)

        if (isActive) {
            val chip = Ui.text(this, "ACTIVE", 11f, Color.WHITE, true)
            chip.setPadding(dp(12), dp(5), dp(12), dp(5))
            chip.background = Ui.rounded(this, color, 20)
            top.addView(chip)
        }
        box.addView(top)

        val row = LinearLayout(this)
        row.setPadding(0, dp(14), 0, 0)
        row.addView(Ui.button(this, if (isActive) "Active ✓" else "Use", Ui.tint(color), color) { setActive(inst) }, Ui.weight(this))
        row.addView(Ui.button(this, "Open", Color.WHITE, color, color) {
            startActivity(Intent(this, ManageActivity::class.java).putExtra("inst", inst))
        }, Ui.weight(this))
        row.addView(Ui.button(this, "Export", color, Color.WHITE) { Exporter.ask(this, listOf(inst)) }, Ui.weight(this))
        box.addView(row)
        return box
    }

    private fun optionsCard(): View {
        val box = cardBox()
        box.addView(Ui.text(this, "OPTIONS", 11f, Ui.GREY, true))

        // ---- where exported files are saved ----
        val row0 = LinearLayout(this)
        row0.gravity = Gravity.CENTER_VERTICAL
        row0.setPadding(0, dp(8), 0, 0)
        val col0 = LinearLayout(this)
        col0.orientation = LinearLayout.VERTICAL
        col0.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        col0.addView(Ui.text(this, "Save location", 16f, Ui.INK, true))
        col0.addView(Ui.text(this, "Word, Excel, zip and images go to: " + Folder.name(this), 12f, Ui.GREY))
        row0.addView(col0)
        row0.addView(Ui.button(this, if (Folder.has(this)) "Change" else "Choose", Ui.tint(Ui.PRIMARY), Ui.PRIMARY) {
            Folder.pick(this)
        }, Ui.lp(w = LinearLayout.LayoutParams.WRAP_CONTENT))
        box.addView(row0)

        // ---- floating circle (only in the Circle edition) ----
        CircleOptions.addOptions(this, box) { render() }

        // ---- battery saver ----
        val m = Store.idleMinutes(this)
        val label = if (m == 0) "Off" else if (m < 60) "$m min" else (m / 60).toString() + " h"
        val row3 = LinearLayout(this)
        row3.gravity = Gravity.CENTER_VERTICAL
        row3.setPadding(0, dp(16), 0, 0)
        val col3 = LinearLayout(this)
        col3.orientation = LinearLayout.VERTICAL
        col3.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        col3.addView(Ui.text(this, "Battery saver", 16f, Ui.INK, true))
        col3.addView(Ui.text(this, "Auto turn OFF after $label with no screenshots", 12f, Ui.GREY))
        row3.addView(col3)
        row3.addView(Ui.button(this, "Change", Ui.tint(Ui.PRIMARY), Ui.PRIMARY) {
            val opts = listOf(0, 30, 60, 120, 240)
            Store.setIdleMinutes(this, opts[(opts.indexOf(m).coerceAtLeast(0) + 1) % opts.size])
            refreshService()
            render()
        }, Ui.lp(w = LinearLayout.LayoutParams.WRAP_CONTENT))
        box.addView(row3)

        box.addView(
            Ui.button(this, "Setup guide (permissions)", Color.WHITE, Ui.PRIMARY, Ui.PRIMARY, 14f) { openSetup() },
            Ui.lp().apply { topMargin = dp(16) }
        )
        return box
    }

    private fun setActive(inst: String) {
        Store.setActive(this, inst)
        if (Store.running(this)) {
            startService(
                Intent(this, ScreenshotService::class.java)
                    .setAction(ScreenshotService.ACTION_SWITCH).putExtra("inst", inst)
            )
        }
        render()
    }

    private fun startCapture() {
        if (!Perms.photosOk(this)) {
            toast("First allow photo access - the setup guide opens it for you")
            openSetup()
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, ScreenshotService::class.java))
        if (!Perms.notifOk(this)) toast("Tip: allow notifications in the setup guide to see the ON status and name prompts")
    }

    private fun stopCapture() {
        startService(Intent(this, ScreenshotService::class.java).setAction(ScreenshotService.ACTION_STOP))
        Store.setRunning(this, false)
        render()
    }
}
