package com.testevidence

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.Toast
import java.io.File

/** The folder the user picks (Storage Access Framework, no special permission needed). */
object Folder {
    const val REQ_PICK = 4107
    var pendingAfterPick: (() -> Unit)? = null

    fun has(c: Context): Boolean = Store.exportTree(c) != null

    fun pick(act: Activity) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        i.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
        try {
            act.startActivityForResult(i, REQ_PICK)
        } catch (e: Exception) {
            Toast.makeText(act, "No file manager found on this phone", Toast.LENGTH_LONG).show()
        }
    }

    /** Call from onActivityResult. Returns true when the result belonged to the folder picker. */
    fun handle(act: Activity, req: Int, res: Int, data: Intent?): Boolean {
        if (req != REQ_PICK) return false
        val uri = data?.data
        if (res == Activity.RESULT_OK && uri != null) {
            try {
                act.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (e: Exception) {
                // some providers only grant for this session; still usable now
            }
            Store.setExportTree(act, uri.toString())
            Toast.makeText(act, "Save location set: " + name(act), Toast.LENGTH_SHORT).show()
            val p = pendingAfterPick
            pendingAfterPick = null
            p?.invoke()
        } else {
            pendingAfterPick = null
        }
        return true
    }

    fun name(c: Context): String {
        val s = Store.exportTree(c) ?: return "Not chosen yet"
        val tree = Uri.parse(s)
        val fallback = Uri.decode(s).substringAfterLast(':')
        return try {
            val doc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            c.contentResolver.query(doc, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: fallback
        } catch (e: Exception) {
            fallback
        }
    }
}

class FolderWriter(private val c: Context) {
    private val tree: Uri? = Store.exportTree(c)?.let { Uri.parse(it) }
    private val cache = HashMap<String, Uri>()

    private fun childDir(t: Uri, parent: Uri, name: String): Uri? {
        val cr = c.contentResolver
        val kids = DocumentsContract.buildChildDocumentsUriUsingTree(t, DocumentsContract.getDocumentId(parent))
        cr.query(
            kids,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE
            ), null, null, null
        )?.use { cur ->
            while (cur.moveToNext()) {
                if (cur.getString(1) == name && cur.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR) {
                    return DocumentsContract.buildDocumentUriUsingTree(t, cur.getString(0))
                }
            }
        }
        return DocumentsContract.createDocument(cr, parent, DocumentsContract.Document.MIME_TYPE_DIR, name)
    }

    fun write(src: File, subs: List<String>, name: String, mime: String): Boolean {
        val t = tree ?: return false
        return try {
            var parent = DocumentsContract.buildDocumentUriUsingTree(t, DocumentsContract.getTreeDocumentId(t))
            var key = ""
            for (s in subs) {
                key += "/$s"
                val hit = cache[key]
                if (hit != null) {
                    parent = hit
                } else {
                    val d = childDir(t, parent, s) ?: return false
                    cache[key] = d
                    parent = d
                }
            }
            val dest = DocumentsContract.createDocument(c.contentResolver, parent, mime, name) ?: return false
            val out = c.contentResolver.openOutputStream(dest) ?: return false
            out.use { o -> src.inputStream().use { it.copyTo(o) } }
            true
        } catch (e: Exception) {
            false
        }
    }
}

object Exporter {
    private class Fmt(val word: Boolean, val excel: Boolean, val zip: Boolean, val images: Boolean)

    private fun mimeOf(f: File): String = when (f.extension.lowercase()) {
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "zip" -> "application/zip"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        else -> "application/octet-stream"
    }

    fun ask(act: Activity, insts: List<String>) {
        val dp = { v: Int -> Ui.dp(act, v) }
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(6), dp(22), 0)
        val loc = Ui.text(act, "Save location: " + Folder.name(act), 13f, Ui.GREY)
        loc.setPadding(0, 0, 0, dp(8))
        box.addView(loc)
        val labels = listOf("Word document (.docx)", "Excel sheet (.xlsx)", "Zip file (.zip)", "Image files (folder only)")
        val boxes = labels.mapIndexed { i, l ->
            val cb = CheckBox(act)
            cb.text = l
            cb.isChecked = i == 0
            box.addView(cb)
            cb
        }
        fun sel() = Fmt(boxes[0].isChecked, boxes[1].isChecked, boxes[2].isChecked, boxes[3].isChecked)
        AlertDialog.Builder(act)
            .setTitle("Export " + insts.joinToString(", "))
            .setView(box)
            .setPositiveButton("Save to folder") { _, _ -> go(act, insts, sel(), true) }
            .setNeutralButton("Share") { _, _ -> go(act, insts, sel(), false) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun go(act: Activity, insts: List<String>, f: Fmt, toFolder: Boolean) {
        if (!f.word && !f.excel && !f.zip && !f.images) {
            Toast.makeText(act, "Tick at least one format", Toast.LENGTH_SHORT).show()
            return
        }
        if (toFolder && !Folder.has(act)) {
            Folder.pendingAfterPick = { go(act, insts, f, true) }
            Toast.makeText(act, "Choose the folder where files should be saved", Toast.LENGTH_LONG).show()
            Folder.pick(act)
            return
        }
        Toast.makeText(act, "Preparing...", Toast.LENGTH_SHORT).show()
        Thread {
            val built = ArrayList<File>()
            var saved = 0
            var failed = 0
            try {
                val fw = FolderWriter(act)
                insts.forEach { inst ->
                    if (f.word) ExportBuilder.docx(act, inst)?.let { built.add(it) }
                    if (f.excel) ExportBuilder.xlsx(act, inst)?.let { built.add(it) }
                    if (f.zip) Store.zip(act, inst)?.let { built.add(it) }
                    if (toFolder && f.images) {
                        Store.groups(act, inst).forEach { g ->
                            g.second.forEach { img ->
                                val subs = if (g.first.isBlank()) listOf(inst) else listOf(inst, g.first)
                                if (fw.write(img, subs, img.name, mimeOf(img))) saved++ else failed++
                            }
                        }
                    }
                }
                if (toFolder) {
                    built.forEach { if (fw.write(it, emptyList(), it.name, mimeOf(it))) saved++ else failed++ }
                }
            } catch (e: Exception) {
                act.runOnUiThread { Toast.makeText(act, "Export failed: " + e.message, Toast.LENGTH_LONG).show() }
                return@Thread
            }
            act.runOnUiThread {
                if (toFolder) {
                    val msg = if (saved == 0 && failed == 0) "No screenshots to export"
                    else if (failed > 0) "Saved $saved, failed $failed. Choose the folder again in Options."
                    else "Saved $saved file(s) to " + Folder.name(act)
                    Toast.makeText(act, msg, Toast.LENGTH_LONG).show()
                } else if (built.isEmpty()) {
                    Toast.makeText(act, "Nothing to share (images can only be saved to a folder)", Toast.LENGTH_LONG).show()
                } else {
                    Store.shareFiles(act, built)
                }
            }
        }.start()
    }
}
