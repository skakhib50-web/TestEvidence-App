package com.testevidence

import java.io.File
import java.io.OutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** No Android classes in here, so it can be tested on any JVM. */
class Img(val bytes: ByteArray, val w: Int, val h: Int)

class OfficeGroup(val title: String, val files: List<File>, val captions: List<String>)

object OfficeWriter {
    private const val EMU_IN = 914400.0
    private const val XML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
    private const val COL_EMU = 327L * 9525L   // width of an Excel column of 46 characters

    fun esc(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun put(z: ZipOutputStream, name: String, text: String) {
        z.putNextEntry(ZipEntry(name))
        z.write(text.toByteArray(Charsets.UTF_8))
        z.closeEntry()
    }

    private fun putBytes(z: ZipOutputStream, name: String, b: ByteArray) {
        z.putNextEntry(ZipEntry(name))
        z.write(b)
        z.closeEntry()
    }

    private fun fit(img: Img, maxWIn: Double, maxHIn: Double): Pair<Long, Long> {
        val k = minOf(maxWIn * EMU_IN / img.w, maxHIn * EMU_IN / img.h)
        return Pair((img.w * k).toLong().coerceAtLeast(1), (img.h * k).toLong().coerceAtLeast(1))
    }

    // ======================================================== DOCX
    private class Pic(val id: Int, val cx: Long, val cy: Long, val caption: String)

    private fun para(text: String, sizeHalfPt: Int, color: String, bold: Boolean, before: Int, after: Int): String {
        val sb = StringBuilder()
        sb.append("<w:p><w:pPr><w:keepNext/><w:spacing w:before=\"").append(before)
            .append("\" w:after=\"").append(after).append("\"/></w:pPr><w:r><w:rPr>")
        if (bold) sb.append("<w:b/>")
        sb.append("<w:color w:val=\"").append(color).append("\"/><w:sz w:val=\"").append(sizeHalfPt).append("\"/></w:rPr>")
        sb.append("<w:t xml:space=\"preserve\">").append(esc(text)).append("</w:t></w:r></w:p>")
        return sb.toString()
    }

    private fun picPara(p: Pic): String =
        "<w:p><w:pPr><w:keepNext/><w:jc w:val=\"center\"/></w:pPr><w:r><w:drawing>" +
            "<wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\">" +
            "<wp:extent cx=\"${p.cx}\" cy=\"${p.cy}\"/>" +
            "<wp:docPr id=\"${p.id}\" name=\"Picture ${p.id}\"/>" +
            "<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect=\"1\"/></wp:cNvGraphicFramePr>" +
            "<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
            "<pic:pic><pic:nvPicPr><pic:cNvPr id=\"${p.id}\" name=\"image${p.id}.jpg\"/><pic:cNvPicPr/></pic:nvPicPr>" +
            "<pic:blipFill><a:blip r:embed=\"rId${p.id}\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
            "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"${p.cx}\" cy=\"${p.cy}\"/></a:xfrm>" +
            "<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>" +
            "</a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>"

    private fun docCell(p: Pic?): String {
        val sb = StringBuilder("<w:tc><w:tcPr><w:tcW w:w=\"4945\" w:type=\"dxa\"/></w:tcPr>")
        if (p == null) {
            sb.append("<w:p/>")
        } else {
            sb.append(picPara(p))
            sb.append(
                "<w:p><w:pPr><w:jc w:val=\"center\"/></w:pPr><w:r><w:rPr><w:color w:val=\"555555\"/><w:sz w:val=\"18\"/></w:rPr>" +
                    "<w:t xml:space=\"preserve\">" + esc(p.caption) + "</w:t></w:r></w:p>"
            )
        }
        sb.append("</w:tc>")
        return sb.toString()
    }

    private fun docTable(pics: List<Pic>): String {
        val b = "w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"D7DDE8\""
        val sb = StringBuilder()
        sb.append("<w:tbl><w:tblPr><w:tblW w:w=\"9890\" w:type=\"dxa\"/><w:tblBorders>")
        sb.append("<w:top $b/><w:left $b/><w:bottom $b/><w:right $b/><w:insideH $b/><w:insideV $b/>")
        sb.append("</w:tblBorders><w:tblLayout w:type=\"fixed\"/>")
        sb.append("<w:tblCellMar><w:top w:w=\"80\" w:type=\"dxa\"/><w:left w:w=\"100\" w:type=\"dxa\"/>")
        sb.append("<w:bottom w:w=\"80\" w:type=\"dxa\"/><w:right w:w=\"100\" w:type=\"dxa\"/></w:tblCellMar></w:tblPr>")
        sb.append("<w:tblGrid><w:gridCol w:w=\"4945\"/><w:gridCol w:w=\"4945\"/></w:tblGrid>")
        var i = 0
        while (i < pics.size) {
            sb.append("<w:tr><w:trPr><w:cantSplit/></w:trPr>")
            sb.append(docCell(pics[i]))
            sb.append(docCell(if (i + 1 < pics.size) pics[i + 1] else null))
            sb.append("</w:tr>")
            i += 2
        }
        sb.append("</w:tbl><w:p/>")
        return sb.toString()
    }

    fun writeDocx(out: OutputStream, title: String, subtitle: String, groups: List<OfficeGroup>, load: (File) -> Img?) {
        val body = StringBuilder()
        val rels = StringBuilder()
        body.append(para(title, 40, "0B1F44", true, 0, 60))
        body.append(para(subtitle, 20, "6B7280", false, 0, 200))
        ZipOutputStream(out.buffered()).use { z ->
            put(z, "[Content_Types].xml",
                XML + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                    "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                    "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                    "<Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>" +
                    "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
                    "</Types>")
            put(z, "_rels/.rels",
                XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
                    "</Relationships>")
            var n = 0
            groups.forEach { g ->
                if (groups.size > 1 || g.title.isNotBlank()) {
                    body.append(para(if (g.title.isBlank()) "General" else "Module: " + g.title, 30, "1565C0", true, 240, 120))
                }
                val pics = ArrayList<Pic>()
                g.files.forEachIndexed { idx, f ->
                    val im = load(f)
                    if (im != null) {
                        n++
                        putBytes(z, "word/media/image$n.jpg", im.bytes)
                        rels.append("<Relationship Id=\"rId$n\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/image$n.jpg\"/>")
                        val sz = fit(im, 3.2, 4.6)
                        pics.add(Pic(n, sz.first, sz.second, g.captions.getOrElse(idx) { f.nameWithoutExtension }))
                    }
                }
                if (pics.isNotEmpty()) body.append(docTable(pics))
            }
            put(z, "word/document.xml",
                XML + "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
                    "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
                    "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" " +
                    "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
                    "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><w:body>" +
                    body.toString() +
                    "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>" +
                    "<w:pgMar w:top=\"1008\" w:right=\"1008\" w:bottom=\"1008\" w:left=\"1008\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/>" +
                    "</w:sectPr></w:body></w:document>")
            put(z, "word/_rels/document.xml.rels",
                XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    rels.toString() + "</Relationships>")
        }
    }

    // ======================================================== XLSX
    private fun cellStr(ref: String, text: String, style: Int): String =
        "<c r=\"$ref\" t=\"inlineStr\"" + (if (style > 0) " s=\"$style\"" else "") +
            "><is><t xml:space=\"preserve\">" + esc(text) + "</t></is></c>"

    private fun pt(v: Double): String = String.format(Locale.US, "%.1f", v)

    private fun anchor(col: Int, row0: Int, sz: Pair<Long, Long>, n: Int): String {
        val colOff = ((COL_EMU - sz.first) / 2).coerceAtLeast(0)
        return "<xdr:oneCellAnchor><xdr:from><xdr:col>$col</xdr:col><xdr:colOff>$colOff</xdr:colOff>" +
            "<xdr:row>$row0</xdr:row><xdr:rowOff>50800</xdr:rowOff></xdr:from>" +
            "<xdr:ext cx=\"${sz.first}\" cy=\"${sz.second}\"/>" +
            "<xdr:pic><xdr:nvPicPr><xdr:cNvPr id=\"${n + 1}\" name=\"Picture $n\"/><xdr:cNvPicPr><a:picLocks noChangeAspect=\"1\"/></xdr:cNvPicPr></xdr:nvPicPr>" +
            "<xdr:blipFill><a:blip r:embed=\"rId$n\"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill>" +
            "<xdr:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"${sz.first}\" cy=\"${sz.second}\"/></a:xfrm>" +
            "<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor>"
    }

    private class XImg(val img: Img, val caption: String, val n: Int)

    fun writeXlsx(out: OutputStream, title: String, subtitle: String, groups: List<OfficeGroup>, load: (File) -> Img?) {
        val rows = StringBuilder()
        val anchors = StringBuilder()
        val drels = StringBuilder()
        var r = 1
        rows.append("<row r=\"$r\" ht=\"26\" customHeight=\"1\">").append(cellStr("A$r", title, 1)).append("</row>")
        r++
        rows.append("<row r=\"$r\">").append(cellStr("A$r", subtitle, 0)).append("</row>")
        r++
        rows.append("<row r=\"$r\" ht=\"10\" customHeight=\"1\"/>")
        r++
        ZipOutputStream(out.buffered()).use { z ->
            put(z, "[Content_Types].xml",
                XML + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                    "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                    "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                    "<Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>" +
                    "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                    "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                    "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                    "<Override PartName=\"/xl/drawings/drawing1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.drawing+xml\"/>" +
                    "</Types>")
            put(z, "_rels/.rels",
                XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                    "</Relationships>")
            put(z, "xl/workbook.xml",
                XML + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
                    "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                    "<sheets><sheet name=\"Evidence\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>")
            put(z, "xl/_rels/workbook.xml.rels",
                XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                    "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
                    "</Relationships>")
            put(z, "xl/styles.xml",
                XML + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                    "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"14\"/><name val=\"Calibri\"/></font></fonts>" +
                    "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
                    "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
                    "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                    "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
                    "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/></cellXfs>" +
                    "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>")

            var n = 0
            groups.forEach { g ->
                if (groups.size > 1 || g.title.isNotBlank()) {
                    rows.append("<row r=\"$r\" ht=\"24\" customHeight=\"1\">")
                        .append(cellStr("A$r", if (g.title.isBlank()) "General" else "Module: " + g.title, 1)).append("</row>")
                    r++
                }
                val imgs = ArrayList<XImg>()
                g.files.forEachIndexed { idx, f ->
                    val im = load(f)
                    if (im != null) {
                        n++
                        putBytes(z, "xl/media/image$n.jpg", im.bytes)
                        drels.append("<Relationship Id=\"rId$n\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"../media/image$n.jpg\"/>")
                        imgs.add(XImg(im, g.captions.getOrElse(idx) { f.nameWithoutExtension }, n))
                    }
                }
                var i = 0
                while (i < imgs.size) {
                    val a = imgs[i]
                    val b = if (i + 1 < imgs.size) imgs[i + 1] else null
                    val sa = fit(a.img, 3.2, 4.6)
                    val sb2 = if (b != null) fit(b.img, 3.2, 4.6) else null
                    val hPts = maxOf(sa.second, sb2?.second ?: 0L) / 12700.0 + 10
                    rows.append("<row r=\"$r\" ht=\"${pt(hPts)}\" customHeight=\"1\"/>")
                    anchors.append(anchor(0, r - 1, sa, a.n))
                    if (b != null && sb2 != null) anchors.append(anchor(1, r - 1, sb2, b.n))
                    r++
                    rows.append("<row r=\"$r\" ht=\"20\" customHeight=\"1\">").append(cellStr("A$r", a.caption, 0))
                    if (b != null) rows.append(cellStr("B$r", b.caption, 0))
                    rows.append("</row>")
                    r++
                    i += 2
                }
                rows.append("<row r=\"$r\" ht=\"12\" customHeight=\"1\"/>")
                r++
            }

            put(z, "xl/worksheets/sheet1.xml",
                XML + "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
                    "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                    "<sheetPr><pageSetUpPr fitToPage=\"1\"/></sheetPr>" +
                    "<cols><col min=\"1\" max=\"2\" width=\"46\" customWidth=\"1\"/></cols>" +
                    "<sheetData>" + rows.toString() + "</sheetData>" +
                    "<pageMargins left=\"0.4\" right=\"0.4\" top=\"0.5\" bottom=\"0.5\" header=\"0.3\" footer=\"0.3\"/>" +
                    "<pageSetup paperSize=\"9\" orientation=\"portrait\" fitToWidth=\"1\" fitToHeight=\"0\"/>" +
                    "<drawing r:id=\"rId1\"/></worksheet>")
            put(z, "xl/worksheets/_rels/sheet1.xml.rels",
                XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing\" Target=\"../drawings/drawing1.xml\"/>" +
                    "</Relationships>")
            put(z, "xl/drawings/drawing1.xml",
                XML + "<xdr:wsDr xmlns:xdr=\"http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing\" " +
                    "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
                    "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                    anchors.toString() + "</xdr:wsDr>")
            put(z, "xl/drawings/_rels/drawing1.xml.rels",
                XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    drels.toString() + "</Relationships>")
        }
    }
}
