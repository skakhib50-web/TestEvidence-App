package com.testevidence

/** Safe edition: no accessibility service at all. Keeps the same API so shared code compiles. */
class CaptureAccessibilityService {
    companion object {
        @Volatile @JvmField var instance: CaptureAccessibilityService? = null
    }
    fun refreshOverlay() {}
}
