package com.testevidence

import android.app.Activity
import android.content.Context
import android.widget.LinearLayout

object CircleOptions {
    const val AVAILABLE = false
    fun a11yReady(c: Context): Boolean = true
    fun openA11y(act: Activity) {}
    fun addOptions(act: Activity, box: LinearLayout, rerender: () -> Unit) {}
}
