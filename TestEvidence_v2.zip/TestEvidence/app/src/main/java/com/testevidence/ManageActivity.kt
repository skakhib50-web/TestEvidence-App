package com.testevidence

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import java.io.File
import java.util.Collections

class ManageActivity : Activity() {

    private lateinit var inst: String
    private var sv: ScrollView? = null

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        inst = intent.getStringExtra("inst") ?: "C1"
        window.statusBarColor = Ui.colorFor(inst)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val files = Store.files(this, inst)
        val color = Ui.colorFor(inst)
        val y = sv?.scrollY ?: 0

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setBackgroundColor(Ui.BG)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(20), dp(32), dp(20), dp(20))
        val hb = GradientDrawable()
        hb.setColor(color)
        val r = dp(28).toFloat()
        hb.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        header.background = hb
        val back = Ui.text(this, "‹  Back", 15f, Color.WHITE, true)
        back.setPadding(0, 0, 0, dp(10))
        back.setOnClickListener { finish() }
        header.addView(back)
        header.addView(Ui.text(this, inst, 28f, Color.WHITE, true))
        val sub = Ui.text(this, files.size.toString() + " screenshot(s). Tap a picture to view it full size.", 13f, 0xCCFFFFFF.toInt())
        sub.setPadding(0, dp(2), 0, dp(14))
        header.addView(sub)
        val row = LinearLayout(this)
        row.addView(Ui.button(this, "Share zip", Color.WHITE, color) {
            Thread {
                val z = Store.zip(this, inst)
                runOnUiThread { if (z == null) toast("No screenshots to zip") else Store.shareZips(this, listOf(z)) }
            }.start()
        }, Ui.weight(this))
        row.addView(Ui.button(this, "Clear all", 0x33FFFFFF, Color.WHITE) {
            if (files.isEmpty()) return@button
            AlertDialog.Builder(this)
                .setTitle("Clear all of $inst?")
                .setMessage("They move to Recently deleted and can be restored for " + Store.TRASH_DAYS + " days.")
                .setPositiveButton("Clear") { _, _ -> Store.clear(this, inst); render() }
                .setNegativeButton("Cancel", null)
                .show()
        }, Ui.weight(this))
        header.addView(row)
        page.addView(header)

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(11), dp(10), dp(11), dp(24))
        if (files.isEmpty()) {
            val e = Ui.text(this, "No screenshots yet.\nStart capturing and take a screenshot.", 15f, Ui.GREY)
            e.setPadding(dp(8), dp(30), dp(8), 0)
            body.addView(e)
        }
        var i = 0
        while (i < files.size) {
            val line = LinearLayout(this)
            line.addView(cell(files, i, color))
            if (i + 1 < files.size) line.addView(cell(files, i + 1, color))
            else line.addView(View(this), Ui.weight(this, 5))
            body.addView(line)
            i += 2
        }
        page.addView(body)

        val s = ScrollView(this)
        s.setBackgroundColor(Ui.BG)
        s.addView(page)
        sv = s
        setContentView(s)
        s.post { s.scrollTo(0, y) }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun cell(files: List<File>, idx: Int, color: Int): View {
        val f = files[idx]
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.setPadding(dp(8), dp(8), dp(8), dp(8))
        cell.background = Ui.rounded(this, Color.WHITE, 14, Ui.LINE, 1)
        cell.elevation = dp(2).toFloat()
        cell.layoutParams = Ui.weight(this, 5).apply { topMargin = dp(5); bottomMargin = dp(5) }

        val iv = ImageView(this)
        iv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(170))
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.background = Ui.rounded(this, Ui.tint(color), 10)
        iv.clipToOutline = true
        iv.setOnClickListener { open(f) }
        Ui.loadInto(iv, f, 400)
        cell.addView(iv)

        val name = Ui.text(this, f.name, 12f, Ui.INK, true)
        name.setPadding(dp(2), dp(6), 0, dp(6))
        cell.addView(name)

        val ctl = LinearLayout(this)
        if (idx > 0) ctl.addView(Ui.button(this, "◀", Ui.tint(color), color, 0, 13f) { swap(files, idx, idx - 1) }, Ui.weight(this, 2))
        if (idx < files.size - 1) ctl.addView(Ui.button(this, "▶", Ui.tint(color), color, 0, 13f) { swap(files, idx, idx + 1) }, Ui.weight(this, 2))
        ctl.addView(Ui.button(this, "Delete", 0x1AD32F2F, Ui.RED, 0, 12f) {
            Store.delete(this, inst, f)
            toast("Moved to Recently deleted")
            render()
        }, Ui.weight(this, 2))
        cell.addView(ctl)
        return cell
    }

    private fun swap(files: List<File>, a: Int, b: Int) {
        val l = files.toMutableList()
        Collections.swap(l, a, b)
        Store.renumber(this, inst, l)
        render()
    }

    private fun open(f: File) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(Store.uriFor(this, f), "image/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            toast("No app found to open images")
        }
    }
}
