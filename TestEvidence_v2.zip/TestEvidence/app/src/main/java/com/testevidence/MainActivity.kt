package com.testevidence

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { render() }
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF0D47A1.toInt()
        Thread { Store.purgeOld(this) }.start()
        render()
    }

    override fun onResume() {
        super.onResume()
        ContextCompat.registerReceiver(
            this, receiver, IntentFilter(ScreenshotService.ACTION_UPDATED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        render()
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    private fun render() {
        val running = Store.running(this)
        val active = Store.active(this)

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setBackgroundColor(Ui.BG)

        // ---- header ----
        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(20), dp(36), dp(20), dp(24))
        val hb = GradientDrawable(
            GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF0D47A1.toInt(), 0xFF1E88E5.toInt())
        )
        val r = dp(28).toFloat()
        hb.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        header.background = hb
        header.addView(Ui.text(this, "Test Evidence", 26f, Color.WHITE, true))
        val sub = Ui.text(this, "Screenshots sorted automatically into C1 · C2 · C3", 13f, 0xCCFFFFFF.toInt())
        sub.setPadding(0, dp(4), 0, dp(14))
        header.addView(sub)
        val pill = Ui.text(
            this, if (running) "●  Capturing  →  $active" else "○  Not capturing", 13f, Color.WHITE, true
        )
        pill.setPadding(dp(14), dp(7), dp(14), dp(7))
        pill.background = Ui.rounded(this, 0x33FFFFFF, 20)
        header.addView(pill, Ui.lp(h = LinearLayout.LayoutParams.WRAP_CONTENT).apply { width = LinearLayout.LayoutParams.WRAP_CONTENT })
        header.addView(
            Ui.button(this, if (running) "Stop capturing" else "Start capturing", Color.WHITE,
                if (running) Ui.RED else Ui.PRIMARY, 0, 16f) {
                if (running) stopCapture() else startCapture()
            },
            Ui.lp().apply { topMargin = dp(16) }
        )
        page.addView(header)

        // ---- body ----
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(16), dp(4), dp(16), dp(28))
        Store.INSTANCES.forEach { body.addView(card(it, it == active)) }
        body.addView(
            Ui.button(this, "Zip & Share ALL instances", Ui.PRIMARY, Color.WHITE, 0, 15f) {
                zipAndShare(Store.INSTANCES)
            },
            Ui.lp().apply { topMargin = dp(18) }
        )
        val tc = Store.trash(this).size
        body.addView(
            Ui.button(this, "Recently deleted ($tc)", Color.WHITE, Ui.PRIMARY, Ui.PRIMARY, 14f) {
                startActivity(Intent(this, TrashActivity::class.java))
            },
            Ui.lp().apply { topMargin = dp(10) }
        )
        page.addView(body)

        val sv = ScrollView(this)
        sv.setBackgroundColor(Ui.BG)
        sv.isFillViewport = true
        sv.addView(page)
        setContentView(sv)
    }

    private fun card(inst: String, isActive: Boolean): View {
        val files = Store.files(this, inst)
        val color = Ui.colorFor(inst)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(14), dp(14), dp(14), dp(14))
        box.background = Ui.rounded(this, Color.WHITE, 18, if (isActive) color else Ui.LINE, if (isActive) 2 else 1)
        box.elevation = dp(2).toFloat()
        box.layoutParams = Ui.lp().apply { topMargin = dp(12) }

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        val iv = ImageView(this)
        iv.layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.background = Ui.rounded(this, Ui.tint(color), 14)
        iv.clipToOutline = true
        if (files.isNotEmpty()) Ui.loadInto(iv, files.last())
        top.addView(iv)

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        info.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        info.setPadding(dp(12), 0, 0, 0)
        info.addView(Ui.text(this, inst, 22f, color, true))
        info.addView(Ui.text(this, files.size.toString() + (if (files.size == 1) " screenshot" else " screenshots"), 13f, Ui.GREY))
        top.addView(info)

        if (isActive) {
            val chip = Ui.text(this, "ACTIVE", 11f, Color.WHITE, true)
            chip.setPadding(dp(10), dp(4), dp(10), dp(4))
            chip.background = Ui.rounded(this, color, 20)
            top.addView(chip)
        }
        box.addView(top)

        val row = LinearLayout(this)
        row.setPadding(0, dp(12), 0, 0)
        row.addView(Ui.button(this, if (isActive) "Active ✓" else "Use", Ui.tint(color), color) { setActive(inst) }, Ui.weight(this))
        row.addView(Ui.button(this, "Open", Color.WHITE, color, color) {
            startActivity(Intent(this, ManageActivity::class.java).putExtra("inst", inst))
        }, Ui.weight(this))
        row.addView(Ui.button(this, "Share zip", color, Color.WHITE) { zipAndShare(listOf(inst)) }, Ui.weight(this))
        box.addView(row)
        return box
    }

    private fun setActive(inst: String) {
        Store.setActive(this, inst)
        if (Store.running(this)) {
            startService(
                Intent(this, ScreenshotService::class.java)
                    .setAction(ScreenshotService.ACTION_SWITCH).putExtra("inst", inst)
            )
        }
        render()
    }

    private fun zipAndShare(list: List<String>) {
        toast("Preparing zip...")
        Thread {
            val zips = list.mapNotNull { Store.zip(this, it) }
            runOnUiThread {
                if (zips.isEmpty()) toast("No screenshots to zip") else Store.shareZips(this, zips)
            }
        }.start()
    }

    private fun mediaPerm() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun startCapture() {
        val need = ArrayList<String>()
        if (checkSelfPermission(mediaPerm()) != PackageManager.PERMISSION_GRANTED) need.add(mediaPerm())
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT < 30 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), 1); return }
        proceedAfterPerms()
    }

    private fun proceedAfterPerms() {
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            toast("Turn ON \"Allow access to manage all files\" for this app, then come back and tap Start again.")
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + packageName))
            )
            return
        }
        launchService()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(mediaPerm()) == PackageManager.PERMISSION_GRANTED) proceedAfterPerms()
        else toast("Photos access (Allow all) is needed to detect screenshots")
    }

    private fun launchService() {
        ContextCompat.startForegroundService(this, Intent(this, ScreenshotService::class.java))
    }

    private fun stopCapture() {
        startService(Intent(this, ScreenshotService::class.java).setAction(ScreenshotService.ACTION_STOP))
        Store.setRunning(this, false)
        render()
    }
}
