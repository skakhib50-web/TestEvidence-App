package com.testevidence

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

object Ui {
    val BG = 0xFFF4F6FA.toInt()
    val INK = 0xFF1B1F2A.toInt()
    val GREY = 0xFF6B7280.toInt()
    val LINE = 0xFFE5E7EB.toInt()
    val PRIMARY = 0xFF1565C0.toInt()
    val RED = 0xFFD32F2F.toInt()
    val WHITE = 0xFFFFFFFF.toInt()
    val pool: ExecutorService = Executors.newFixedThreadPool(3)

    fun colorFor(inst: String): Int = when (inst) {
        "C1" -> 0xFF1E88E5.toInt()
        "C2" -> 0xFF2E7D32.toInt()
        else -> 0xFFEF6C00.toInt()
    }

    fun tint(color: Int): Int = (color and 0x00FFFFFF) or 0x22000000

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(c: Context, color: Int, radiusDp: Int, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(c, radiusDp).toFloat()
        if (stroke != 0 && strokeDp > 0) g.setStroke(dp(c, strokeDp), stroke)
        return g
    }

    fun text(c: Context, s: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = s
        t.textSize = sizeSp
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    fun button(
        c: Context, s: String, bg: Int, fg: Int, stroke: Int = 0, sizeSp: Float = 13f, onClick: () -> Unit
    ): TextView {
        val t = TextView(c)
        t.text = s
        t.textSize = sizeSp
        t.setTextColor(fg)
        t.setTypeface(null, Typeface.BOLD)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.setPadding(dp(c, 8), dp(c, 11), dp(c, 8), dp(c, 11))
        t.background = RippleDrawable(ColorStateList.valueOf(0x33000000), rounded(c, bg, 12, stroke, 1), null)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        return t
    }

    fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT) =
        LinearLayout.LayoutParams(w, h)

    fun weight(c: Context, marginDp: Int = 3): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        p.setMargins(dp(c, marginDp), 0, dp(c, marginDp), 0)
        return p
    }

    fun thumb(f: File, target: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= target && o.outHeight / (s * 2) >= target) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    fun loadInto(iv: ImageView, f: File, target: Int = 240) {
        pool.execute {
            val bm = thumb(f, target)
            iv.post { iv.setImageBitmap(bm) }
        }
    }

    fun ago(ms: Long): String {
        val m = (System.currentTimeMillis() - ms) / 60000
        return when {
            m < 1 -> "just now"
            m < 60 -> "$m min ago"
            m < 1440 -> "${m / 60} h ago"
            else -> "${m / 1440} d ago"
        }
    }
}
