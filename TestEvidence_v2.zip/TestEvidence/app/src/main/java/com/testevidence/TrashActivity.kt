package com.testevidence

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

class TrashActivity : Activity() {

    private fun dp(v: Int) = Ui.dp(this, v)
    private val head = 0xFF455A64.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = head
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val items = Store.trash(this)

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setBackgroundColor(Ui.BG)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(dp(20), dp(32), dp(20), dp(20))
        val hb = GradientDrawable()
        hb.setColor(head)
        val r = dp(28).toFloat()
        hb.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        header.background = hb
        val back = Ui.text(this, "‹  Back", 15f, Color.WHITE, true)
        back.setPadding(0, 0, 0, dp(10))
        back.setOnClickListener { finish() }
        header.addView(back)
        header.addView(Ui.text(this, "Recently deleted", 26f, Color.WHITE, true))
        val sub = Ui.text(
            this, "Items are removed for good after " + Store.TRASH_DAYS + " days.", 13f, 0xCCFFFFFF.toInt()
        )
        sub.setPadding(0, dp(2), 0, dp(14))
        header.addView(sub)
        header.addView(Ui.button(this, "Empty trash (" + items.size + ")", 0x33FFFFFF, Color.WHITE) {
            if (items.isEmpty()) return@button
            AlertDialog.Builder(this)
                .setTitle("Delete all permanently?")
                .setMessage("This cannot be undone.")
                .setPositiveButton("Delete") { _, _ -> Store.emptyTrash(this); render() }
                .setNegativeButton("Cancel", null)
                .show()
        })
        page.addView(header)

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(16), dp(8), dp(16), dp(24))
        if (items.isEmpty()) {
            val e = Ui.text(this, "Nothing here. Deleted screenshots appear here.", 15f, Ui.GREY)
            e.setPadding(dp(4), dp(30), dp(4), 0)
            body.addView(e)
        }
        items.forEach { body.addView(row(it)) }
        page.addView(body)

        val s = ScrollView(this)
        s.setBackgroundColor(Ui.BG)
        s.addView(page)
        setContentView(s)
    }

    private fun row(t: Store.TrashItem): View {
        val color = Ui.colorFor(t.inst)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(12), dp(12), dp(12))
        box.background = Ui.rounded(this, Color.WHITE, 16, Ui.LINE, 1)
        box.elevation = dp(2).toFloat()
        box.layoutParams = Ui.lp().apply { topMargin = dp(10) }

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val iv = ImageView(this)
        iv.layoutParams = LinearLayout.LayoutParams(dp(64), dp(64))
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.background = Ui.rounded(this, Ui.tint(color), 12)
        iv.clipToOutline = true
        Ui.loadInto(iv, t.file)
        top.addView(iv)

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        info.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        info.setPadding(dp(12), 0, 0, 0)
        info.addView(Ui.text(this, "From " + t.inst, 17f, color, true))
        info.addView(Ui.text(this, "Deleted " + Ui.ago(t.file.lastModified()), 12f, Ui.GREY))
        info.addView(Ui.text(this, "Removed in " + Store.daysLeft(t) + " day(s)", 12f, Ui.GREY))
        top.addView(info)
        box.addView(top)

        val row = LinearLayout(this)
        row.setPadding(0, dp(10), 0, 0)
        row.addView(Ui.button(this, "Restore", color, Color.WHITE) {
            val f = Store.restore(this, t)
            Toast.makeText(this, "Restored as " + f.name, Toast.LENGTH_SHORT).show()
            render()
        }, Ui.weight(this))
        row.addView(Ui.button(this, "Delete forever", 0x1AD32F2F, Ui.RED) {
            Store.deleteForever(t)
            render()
        }, Ui.weight(this))
        box.addView(row)
        return box
    }
}
