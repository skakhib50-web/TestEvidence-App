package com.testevidence

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentUris
import android.content.Intent
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.File
import java.util.concurrent.Executors

/**
 * Battery-friendly: no polling, no wake locks, no timers while idle.
 * It only wakes when Android reports a change in the images database,
 * and it switches itself off after the chosen idle time.
 */
class ScreenshotService : Service() {

    companion object {
        const val ACTION_SWITCH = "com.testevidence.SWITCH"
        const val ACTION_STOP = "com.testevidence.STOP"
        const val ACTION_UPDATED = "com.testevidence.UPDATED"
        private const val CH = "capture"
        private const val NOTIF_ID = 42
        private val IMG = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        @Volatile var instance: ScreenshotService? = null
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    fun refreshNotification() {
        try { getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification()) } catch (e: Exception) {}
    }

    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var observer: ContentObserver? = null
    private val scanRunnable = Runnable { worker.execute { scan() } }
    private val idleStop = Runnable { shutdown() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_SWITCH) {
            intent.getStringExtra("inst")?.let { Store.setActive(this, it) }
        }
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        )
        Store.setRunning(this, true)
        if (observer == null) {
            Store.setLastId(this, maxId())
            val o = object : ContentObserver(handler) {
                override fun onChange(selfChange: Boolean) {
                    handler.removeCallbacks(scanRunnable)
                    handler.postDelayed(scanRunnable, 1500)
                }
            }
            contentResolver.registerContentObserver(IMG, true, o)
            observer = o
        }
        scheduleIdle()
        sendBroadcast(Intent(ACTION_UPDATED).setPackage(packageName))
        CaptureAccessibilityService.instance?.refreshOverlay()
        return START_NOT_STICKY
    }

    private fun scheduleIdle() {
        handler.removeCallbacks(idleStop)
        val m = Store.idleMinutes(this)
        if (m > 0) handler.postDelayed(idleStop, m * 60_000L)
    }

    private fun shutdown() {
        handler.removeCallbacks(idleStop)
        handler.removeCallbacks(scanRunnable)
        Store.setRunning(this, false)
        CaptureAccessibilityService.instance?.refreshOverlay()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        sendBroadcast(Intent(ACTION_UPDATED).setPackage(packageName))
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        observer?.let { contentResolver.unregisterContentObserver(it) }
        observer = null
        Store.setRunning(this, false)
        instance = null
        CaptureAccessibilityService.instance?.refreshOverlay()
        worker.shutdown()
        super.onDestroy()
    }

    private fun maxId(): Long = try {
        contentResolver.query(IMG, arrayOf(MediaStore.Images.Media._ID), null, null,
            MediaStore.Images.Media._ID + " DESC")?.use { if (it.moveToFirst()) it.getLong(0) else 0L } ?: 0L
    } catch (e: Exception) { 0L }

    private fun scan() {
        var imported = 0
        try {
            val proj = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.DATA
            )
            contentResolver.query(
                IMG, proj, MediaStore.Images.Media._ID + " > ?",
                arrayOf(Store.lastId(this).toString()), MediaStore.Images.Media._ID + " ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val name = c.getString(1) ?: ""
                    val path = c.getString(2) ?: ""
                    Store.setLastId(this, id)
                    if (!(path + name).lowercase().contains("screenshot")) continue
                    val ext = name.substringAfterLast('.', "png")
                    val sfx = Store.suffixFor(Store.currentModule(this), "")
                    val dest = Store.nextFile(this, Store.active(this), ext, sfx)
                    val uri = ContentUris.withAppendedId(IMG, id)
                    contentResolver.openInputStream(uri)?.use { ins ->
                        dest.outputStream().use { ins.copyTo(it) }
                    }
                    if (dest.length() > 0) {
                        // MOVE: remove the original from the gallery
                        val gone = try { contentResolver.delete(uri, null, null) } catch (e: Exception) { 0 }
                        if (gone == 0 && path.isNotEmpty()) File(path).delete()
                        imported++
                    } else {
                        dest.delete()
                    }
                }
            }
        } catch (e: Exception) {
            // ignore; next change event will retry
        }
        if (imported > 0) {
            scheduleIdle()
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
            sendBroadcast(Intent(ACTION_UPDATED).setPackage(packageName))
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Capturing", NotificationManager.IMPORTANCE_LOW))
        val act = Store.active(this)
        val mod = Store.currentModule(this)
        val counts = Store.INSTANCES.joinToString("   ") { it + ": " + Store.files(this, it).size }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("ON - saving to " + act + (if (mod.isNotEmpty()) "  |  " + mod else ""))
            .setContentText(counts)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setContentIntent(open)
        Store.INSTANCES.forEachIndexed { i, inst ->
            val si = Intent(this, ScreenshotService::class.java).setAction(ACTION_SWITCH).putExtra("inst", inst)
            val pi = PendingIntent.getService(
                this, 10 + i, si, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            b.addAction(0, if (inst == act) "● $inst" else inst, pi)
        }
        return b.build()
    }
}
